<?php

/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Buttons
/*-----------------------------------------------------------------------------------*/
function dani_button( $atts, $content = null )
{
	extract( shortcode_atts( array(
      'type' => 'text',
      'style' => 'style-1',
      'size' => 'medium-button',
      'open' => 'url',
	  'url' => '',
      'target' => '_self',
	  'page' => '',
	  'portfolio' => '',
	  'image' => '',
	  'videoid' => '',
	  'selfhosted' => ''
      ), $atts ) );
	
	
	$href = '';
	$buttonAdd =	 '';	
	if ($open == 'url') { 
		$href = $url;
		$buttonAdd = 'target="'.esc_attr($target).'"';
	} else if ($open == 'page') {
		$href = get_permalink($page); 
	} else if ($open == 'portfolio') {
		$href = get_permalink($portfolio); 
	} else if ($open == 'image') {
		$href = $image; 
		$buttonAdd = 'data-rel="lightcase"';
	} else if ($open == 'youtube') {
		$href = '//www.youtube.com/embed/'.$videoid; 
		$buttonAdd = 'data-rel="lightcase"';
	} else if ($open == 'vimeo') {
		$href = '//player.vimeo.com/video/'.$videoid; 
		$buttonAdd = 'data-rel="lightcase"';
	} else if ($open == 'selfhosted') {
		$href = $selfhosted; 
		$buttonAdd = 'data-rel="lightcase"';
	}
	
	$addClass = '';
	if ($type == 'icon') { $addClass = '-icon'; }
	if ($type == 'arrow') { $addClass = '-with-arrow'; $style = ''; }
	return '<a href="'.esc_url($href).'" class="sr-button'.esc_attr($addClass).' '.esc_attr($style).' button-'.esc_attr($size).'" '.$buttonAdd.'>'.preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content)).'</a>';	
		
	
}
add_shortcode('sr-button', 'dani_button');





/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Icons
/*-----------------------------------------------------------------------------------*/
function dani_iconfont( $atts, $content = null )
{
	extract( shortcode_atts( array(
      'type' => '',
      'size' => 'normal',
      'color' => ''
      ), $atts ) );
	
	$iconcolor = '';
	if ($color && $color !== '') { 
		$iconcolor = 'style="color:'.esc_attr($color).';"';
	}
	
	if ($type[0] == 'i') { 
		return '<i class="ion '.esc_attr($type).' ion-'.esc_attr($size).'" '.$iconcolor.'></i>';	
	}  else {
		return '<i class="fa '.esc_attr($type).' fa-'.esc_attr($size).'" '.$iconcolor.'></i>';	
	}
		
}
add_shortcode('iconfont', 'dani_iconfont');





/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Skills
/*-----------------------------------------------------------------------------------*/
function dani_skill( $atts, $content = null )
{
	extract( shortcode_atts( array(
      'amount' => '55',
	  'name' => 'Skillname',
	  'color' => '#0d0d0d'
      ), $atts ) );
	
	$skill_slug = preg_replace('/[^a-z]/', "", strtolower($name));
	
	if ($color) { $skillcolor = 'background:'.esc_attr($color); } else { $skillcolor = '';  }
		
	return '<div class="skill">
				<h6 class="skill-name title-alt">'.esc_html($name).'</h6>
				<div class="skill-bar"><div class="skill-active '.esc_attr($skill_slug).'" style="'.$skillcolor.'" data-perc="'.esc_attr($amount).'">
				<span class="tooltip">'.esc_html($amount).'%</span></div></div>
			</div>';	
}
add_shortcode('skill', 'dani_skill');




/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Tabs
/*-----------------------------------------------------------------------------------*/
function dani_tabs( $atts, $content = null )
{
	extract( shortcode_atts( array(
      'style' => 'standard',
      'title' => ''
      ), $atts ) );
	
	$return = '<div class="tabs tabs-'.esc_attr($style).'"><ul class="tab-nav clearfix">';
	
	$title = substr($title, 0, -1);
	$title = explode(',', $title);
	$i = 1;
	foreach ($title as $t) {
		if ($i == 1) { $addclass = 'class="active"'; } else { $addclass = ''; }
		$return .= '<li '.$addclass.'><h6 class="tab-name title-alt"><a href="tabid'.esc_attr($i).'"><strong>'.esc_html($t).'</strong></a></h5></li>';	
		$i++;
	}
	
	$return .= '</ul><div class="tab-container clearfix">'.do_shortcode($content).'</div></div>';
	
	return $return;	
}
add_shortcode('tabs', 'dani_tabs');


function dani_tab( $atts, $content = null )
{	
	extract( shortcode_atts( array(
      'id' => ''
      ), $atts ) );
	
	if ($id == 1) { $addclass = 'active'; } else { $addclass = ''; }
	return '<div class="tab-content tabid'.esc_attr($id).' '.esc_attr($addclass).'">' . preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content)) . '</div>';	
}
add_shortcode('tab', 'dani_tab');






/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Toggles
/*-----------------------------------------------------------------------------------*/
function dani_toggle( $atts, $content = null )
{
	extract( shortcode_atts( array(
      'title' => 'Toggle',
      'open' => 'no'
      ), $atts ) );
			
	if ($open == 'yes') { $toggleopen = 'toggle-active'; } else { $toggleopen = ''; }
	
	return '<div class="toggle-item">
				<div class="toggle-title '.esc_attr($toggleopen).'">
					<h5 class="toggle-name title-alt"><strong>' . esc_html($title) . '</strong></h5>
				</div>
				<div class="toggle-inner">'.do_shortcode($content).'</div>
			</div>';
}
add_shortcode('toggle', 'dani_toggle');






/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Accordion
/*-----------------------------------------------------------------------------------*/
function dani_accordion( $atts, $content = null )
{
	extract( shortcode_atts( array(
      'title' => 'Toggle',
      'open' => 'no'
      ), $atts ) );
			
	if ($open == 'yes') { $toggleopen = 'toggle-active'; } else { $toggleopen = ''; }
	
	return '	<div class="toggle-item">
				<div class="toggle-title '.esc_attr($toggleopen).'">
					<h5 class="toggle-name title-alt"><strong>' . esc_html($title) . '</strong></h5>
				</div>
				<div class="toggle-inner">' . preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content)) . '</div>
			</div>';		
}
add_shortcode('accordion', 'dani_accordion');


function dani_accordiongroup( $atts, $content = null )
{	
	return '<div class="accordion">' . preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content)) . '</div>';	
}
add_shortcode('accordiongroup', 'dani_accordiongroup');




/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Content Slider
/*-----------------------------------------------------------------------------------*/
function dani_slide( $atts, $content = null )
{
	return '	<div>'.preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content)).'</div>';		
}
add_shortcode('sr-slide', 'dani_slide');


function dani_contentslider( $atts, $content = null )
{	
	return '<div class="owl-slider content-slider">' . preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content)) . '</div>';	
}
add_shortcode('sr-contentslider', 'dani_contentslider');





/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Social Networks (from Theme options)
/*-----------------------------------------------------------------------------------*/
function dani_social( $atts, $content = null )
{
	extract( shortcode_atts( array(
      'style' => 'normal',
      'list' => 'normal'
	  ), $atts ) );
	
	
	$socials = array('facebook','twitter','googleplus','vimeo','instagram','dribbble','youtube','deviantart','behance','flickr','linkedin','rss','pinterest','xing','dropbox','stumbleupon','delicious','soundcloud','spotify','codepen','github','lastfm','jsfiddle','mixcloud','skype','vk','mail');
	
	$return = '<ul class="socialmedia-widget '.esc_attr($style).'-style '.esc_attr($list).'">';
	foreach($socials as $s) {
		$linkName = '';
		if ($style == 'text') {
			$linkName = 	ucfirst($s);
			if ($s == 'googleplus') { $linkName = 'Google'; }
		}
		if (get_option('_sr_social_'.$s)) { $return .= '<li class="'.$s.'"><a href="'.esc_url(get_option('_sr_social_'.$s)).'" target="_blank">'.$linkName.'</a></li>'; }
	}
	$return .= '</ul>';
	
	return $return;
	
}
add_shortcode('sr-social', 'dani_social');



/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Share
/*-----------------------------------------------------------------------------------*/
function share_sc( $atts, $content = null )
{
	
	extract( shortcode_atts( array(
      'title' => '<strong>Share</strong>',
      'align' => 'left',
      'style' => ''
      ), $atts ) );
	
	return dani_Share(get_post_type(),$title,$align,$style);
}
add_shortcode('dani-share', 'share_sc');



/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Subtitle
/*-----------------------------------------------------------------------------------*/
function dani_subtitle( $atts, $content = null )
{	
	extract( shortcode_atts( array(
      'size' => 'h4',
      'alignment' => 'center',
      'uppercase' => '0'
      ), $atts ) );	
	  
	
	if ($uppercase) { $addClass = ' uppercase'; } else { $addClass = ''; }  
	$return =   '<'.$size.' class="title-alt align-'.esc_attr($alignment).' '.esc_attr($addClass).'">'.preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content)).'</'.$size.'>';
	return $return;	
}
add_shortcode('sr-subtitle', 'dani_subtitle');



/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Inline Video
/*-----------------------------------------------------------------------------------*/
function dani_video( $atts, $content = null )
{
	extract( shortcode_atts( array(
      'type' => '',
      'image' => '',
      'video' => '',
      'id' => '',
      ), $atts ) );
	
	if ($type == 'inline') {
		return '<div class="inline-video" data-type="'.esc_attr($video).'" data-videoid="'.esc_attr($id).'">
					<img src="'.esc_url($image).'" alt="'.esc_html($video).' video">
				</div>';	
	}
	
	else if ($type == 'lightbox') {
		$href = "";
		if ($video == 'youtube') {
			$href = '//www.youtube.com/embed/'.$id; 
		} else if ($video == 'vimeo') {
			$href = '//player.vimeo.com/video/'.$id; 
		}
		return '<a class="inline-lightbox" data-rel="lightcase" href="'.esc_html($href).'">
					<img src="'.esc_url($image).'" alt="'.esc_html($id).' video">
				</a>';	
	}
	
}
add_shortcode('sr-video', 'dani_video');


/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Alert
/*-----------------------------------------------------------------------------------*/
function dani_alert( $atts, $content = null )
{	
	extract( shortcode_atts( array(
      'type' => 'info',
      'title' => ''
      ), $atts ) );	
	  
	
	return '<div class="alert-'.esc_attr($type).'">
            	<h5 class="title-alt alert-title"><strong>'.esc_html($title).'</strong></h5>
                '.preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content)).'
            </div>';	
}
add_shortcode('sr-alert', 'dani_alert');




/*-----------------------------------------------------------------------------------*/
/*	Wordpress Bugfix for shortcodes (paragraph issue)
/*-----------------------------------------------------------------------------------*/
add_filter("the_content", "dani_the_content_filter");
function dani_the_content_filter($content) {
 
	// array of custom shortcodes requiring the fix
	$block = join("|",array(	"accordiongroup",
								"accordion",
								"counter",
								"field",
								"tabs",
								"tab",
								"sr-subtitle",
								"toggle",
								"skill",
								"sr-social",
								"sr-contactform",
								"sr-video",
								"sr-share",
								"sr-contentslider",
								"sr-slide"
								));
	 
	// opening tag
	$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
	// closing tag
	$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
	return $rep;
 
}


/*-----------------------------------------------------------------------------------*/
/*	Register Buttons
/*-----------------------------------------------------------------------------------*/
function dani_init_buttons() {
	// If user has permission
	if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') )
		return;
	 
	// Add only in Rich Editor mode
	if ( get_user_option('rich_editing') == 'true') {
		add_filter("mce_external_plugins", "dani_add_buttons_plugin");
		add_filter('mce_buttons', 'dani_register_buttons');
	}
}
add_action('init', 'dani_init_buttons');

function dani_add_buttons_plugin($plugin_array) {
   	$plugin_array['popupbutton'] = plugins_url( '/tinymcepopup.js', __FILE__ );
	return $plugin_array;
}

function dani_register_buttons($buttons) {
	array_push( $buttons, "popup" );
	return $buttons;
}


?>