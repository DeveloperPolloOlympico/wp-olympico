<?php

/*-----------------------------------------------------------------------------------*/
/*	Fullwidth / Background Section Shortcode
/*-----------------------------------------------------------------------------------*/
function dani_fullwidthsection( $atts, $content = null ) {
	extract( shortcode_atts( array(
      'background' => '0',
      'colorbg' => '',
      'imagebg' => '',
      'imagetype' => 'parallax',
      'selfhostedmp4' => '',
      'selfhostedwebm' => '',
      'selfhostedogv' => '',
      'youtubeid' => '',
      'vimeoid' => '',
      'videoratio' => '16/9',
      'videoloop' => '1',
      'videomute' => '1',
      'videoposter' => '',
      'videooverlaycolor' => '',
      'videooverlayopacity' => '',
      'textcolor' => 'text-dark',
      'pdtop' => '100px',
      'pdbottom' => '100px',
      'class' => '',
      'id' => ''
      ), $atts ) );
	
	
	$return = '';
	$sectionClass = '';  
	$sectionID = '';  
	if ($background !== '0' && $background) {
	
		if ($background == 'color') {
			$sectionAdd = 'style="background-color:'.esc_attr($colorbg).'"';	
			$sectionClass = $textcolor;
		} else if ($background == 'image') {
			if ($imagetype == 'normal') {
				$sectionClass = $textcolor;
				$sectionAdd = 'style="background:url('.esc_url($imagebg).') center center;background-size:cover;"';	
			} else if ($imagetype == 'parallax') {
				$sectionClass = 'parallax-section '.$textcolor;
				$sectionAdd = 'data-parallax-image="'.esc_url($imagebg).'"';	
			} else if ($imagetype == 'pattern') {
				if (strpos($imagebg, '@2x') !== false) {
					$imageInfo = wp_get_attachment_image_src( dani_get_attachment_id_from_src($imagebg), 'full' );	
					$w = $imageInfo[1]/2;
					$h = $imageInfo[2]/2;
					$styleAdd = "-webkit-background-size:".$w."px ".$h."px; -moz-background-size:".$w."px ".$h."px; -o-background-size:".$w."px ".$h."px; background-size:".$w."px ".$h."px;";
				} else { $styleAdd = ""; }
				$sectionClass = $textcolor;
				$sectionAdd = 'style="background:url('.esc_url($imagebg).') center center;'.$styleAdd.'"';	
				
			}
		} else if ($background == 'selfhosted' || $background == 'youtube' || $background == 'vimeo') {
			if ($background == 'selfhosted') {
				$sectionAdd = '	data-phattype="html5" 
								data-phatmp4="'.esc_attr($selfhostedmp4).'" 
								data-phatwebm="'.esc_attr($selfhostedwebm).'" 
								data-phatogv="'.esc_attr($selfhostedogv).'"';	
			} else if ($background == 'youtube') {
				$sectionAdd = '	data-phattype="youtube" 
								data-phatvideoid="'.esc_attr($youtubeid).'"' ;
			} else if ($background == 'vimeo') {
				$sectionAdd = '	data-phattype="vimeo" 
								data-phatvideoid="'.esc_attr($vimeoid).'"' ;
			}
			
			if (!$videoloop) { $loop = "false"; } else {$loop = "true"; }
			if ($videomute) { $mute = "false"; } else {$mute = "true"; }
			if ($videooverlaycolor == '') { $videooverlaycolor = "#ffffff"; $videooverlayopacity = 0; }
			
			$sectionClass = 'videobg-section '.$textcolor;
			$sectionAdd .= '	data-phatratio="'.esc_attr($videoratio).'"
							data-phatposter="'.esc_attr($videoposter).'"
							data-phatloop="'.esc_attr($loop).'"
							data-phatmute="'.esc_attr($mute).'"
							data-phatoverlaycolor="'.esc_attr($videooverlaycolor).'"
							data-phatoverlayopacity="'.esc_attr($videooverlayopacity).'"';
		}
	}
	
	if ($class) { $sectionClass .= ' '.$class; }
	if ($id) { $sectionID = 'id="'.esc_attr($id).'"'; }
	$return .= '<div '.$sectionID.' class="fullwidth-section '.esc_attr($sectionClass).'" '.$sectionAdd.'>';		
	$return .= '<div class="fullwidth-content" style="padding-top:'.esc_attr($pdtop).';padding-bottom:'.esc_attr($pdbottom).';">';
	$return .= preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content));
	$return .= '</div>';	
	$return .= '</div>';	
	
	return $return;
}
add_shortcode('fullwidthsection', 'dani_fullwidthsection');


/*-----------------------------------------------------------------------------------*/
/*	Column Row Shortcode
/*-----------------------------------------------------------------------------------*/
function dani_columnsection( $atts, $content = null ) {
	extract( shortcode_atts( array(
      'wrapper' => 'wrapper',
      'spacing' => 'spaced-normal',
      'class' => '',
      'id' => ''
      ), $atts ) );
	
	$return = '<div class="'.esc_attr($wrapper).'">';	
   	$return .= '<div id="'.esc_attr($id).'" class="column-section clearfix '.esc_attr($spacing).' '.esc_attr($class).'">'.preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content)).'</div>';
	$return .= '</div>';	
	
	return $return;
}
add_shortcode('columnsection', 'dani_columnsection');


function dani_col( $atts, $content = null ) {
	extract( shortcode_atts( array(
      'size' => 'one-full',
      'last' => '',
      'xpadding' => '',
      'ypadding' => '',
	  'background' => '0',
      'colorbg' => '',
      'imagebg' => '',
      'imagetype' => 'parallax',
      'textcolor' => 'text-dark',
      'class' => '',
      'id' => ''
      ), $atts ) );
	  
	$styleAdd = '';	  
	if ($ypadding && $ypadding !== '0px') $styleAdd .= 'padding-top:'.$ypadding.'; padding-bottom:'.$ypadding.';';	  
	if ($xpadding && $xpadding !== '0px') $styleAdd .= 'padding-left:'.$xpadding.'; padding-right:'.$xpadding.';';	 
		
	$sectionAdd = '';  
	$sectionClass = ''; 
	$sectionID = '';  
	if ($background !== '0' && $background) {
		if ($background == 'color') {
			$sectionAdd = 'style="background-color:'.esc_attr($colorbg).';'.$styleAdd.'"';	
			$sectionClass = $textcolor;
		} else if ($background == 'image') {
			$image = wp_get_attachment_image_src( dani_get_attachment_id_from_src($imagebg), 'full' );
			$imageFile = $image[0];
			if ($imagetype == 'normal') {
				$sectionClass = $textcolor;
				$sectionAdd = 'style="background:url('.esc_url($imageFile).') center center;background-size:cover;"';	
			} else if ($imagetype == 'parallax') {
				$sectionClass = 'parallax-section '.$textcolor;
				$sectionAdd = 'data-parallax-image="'.esc_url($imageFile).'" style="'.$styleAdd.'"';	
			} else if ($imagetype == 'pattern') {
				if (strpos($imagebg, '@2x') !== false) {
					$w = $image[1]/2;
					$h = $image[2]/2;
					$styleAdd .= "-webkit-background-size:".$w."px ".$h."px; -moz-background-size:".$w."px ".$h."px; -o-background-size:".$w."px ".$h."px; background-size:".$w."px ".$h."px;";
				} else { $styleAdd = ""; }
				$sectionClass = $textcolor;
				$sectionAdd = 'style="background:url('.esc_url($imageFile).') center center;'.$styleAdd.'"';	
			} 
		} else {
			$sectionAdd = 'style="'.$styleAdd.'"';	
		}
	}
	
	if ($class) { $sectionClass .= ' '.$class; }
	if ($id) { $sectionID = 'id="'.esc_attr($id).'"'; } 
	  
   	return '<div '.$sectionID.' class="column '.esc_attr($size).' '.esc_attr($last).' '.esc_attr($sectionClass).'" '.$sectionAdd.'>'.preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content)).'</div>';
	
}
add_shortcode('col', 'dani_col');




/*-----------------------------------------------------------------------------------*/
/*	Spacer Shortcode
/*-----------------------------------------------------------------------------------*/
function dani_spacer( $atts, $content = null )
{
	extract( shortcode_atts( array(
      'size' => 'big'
      ), $atts ) );
	
	return '<div class="spacer spacer-'.esc_attr($size).'"></div>';
	
}
add_shortcode('sr-spacer', 'dani_spacer');




/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Team
/*-----------------------------------------------------------------------------------*/
function dani_teammember( $atts, $content = null ) {
	
	extract( shortcode_atts( array(
	  'name' => '',
	  'title' => '',
      'image' => '',
      'layout' => 'onhover',
	  'facebook' => '',
	  'behance' => '',
	  'dribbble' => '',
	  'twitter' => '',
	  'google' => '',
	  'instagram' => '',
	  'youtube' => '',
	  'vimeo' => '',
	  'tumblr' => '',
	  'linkedin' => '',
	  'vk' => '',
	  'soundcloud' => '',
	  'website' => '',
	  'mail' => ''
      ), $atts ) );
	
   	
	$social = '';
	if ($facebook || $behance || $dribbble || $twitter || $google || $linkedin || $vk || $website || $soundcloud || $mail) { 
		$social .= '<ul class="socialmedia-widget">';
		if ($facebook) { $social .= '<li class="facebook"><a href="'.esc_url($facebook).'" target="_blank"></a></li>';  }
		if ($twitter) { $social .= '<li class="twitter"><a href="'.esc_url($twitter).'" target="_blank"></a></li>';  }
		if ($google) { $social .= '<li class="googleplus"><a href="'.esc_url($google).'" target="_blank"></a></li>';  }
		if ($behance) { $social .= '<li class="behance"><a href="'.esc_url($behance).'" target="_blank"></a></li>';  }
		if ($dribbble) { $social .= '<li class="dribbble"><a href="'.esc_url($dribbble).'" target="_blank"></a></li>';  }
		if ($instagram) { $social .= '<li class="instagram"><a href="'.esc_url($instagram).'" target="_blank"></a></li>';  }
		if ($youtube) { $social .= '<li class="youtube"><a href="'.esc_url($youtube).'" target="_blank"></a></li>';  }
		if ($vimeo) { $social .= '<li class="vimeo"><a href="'.esc_url($vimeo).'" target="_blank"></a></li>';  }
		if ($tumblr) { $social .= '<li class="tumblr"><a href="'.esc_url($tumblr).'" target="_blank"></a></li>';  }
		if ($linkedin) { $social .= '<li class="linkedin"><a href="'.esc_url($linkedin).'" target="_blank"></a></li>';  }
		if ($vk) { $social .= '<li class="vk"><a href="'.esc_url($vk).'" target="_blank"></a></li>';  }
		if ($website) { $social .= '<li class="url"><a href="'.esc_url($website).'" target="_blank"></a></li>';  }
		if ($soundcloud) { $social .= '<li class="soundcloud"><a href="'.esc_url($soundcloud).'" target="_blank"></a></li>';  }
		if ($mail) { $social .= '<li class="mail"><a href="mailto:'.$mail.'" target="_blank"></a></li>';  }
		$social .= '</ul>';
	}
	
   	$output = '<div class="team-member">';
	
		if ($layout == 'onhover') { $output .= '<div class="thumb-hover overlay-effect text-dark">'; }
		
		if ($image) { $output .= '<img src="'.esc_url($image).'" alt="'.esc_html($name).'">'; }
		
		if ($layout == 'onhover') { 
			$output .= '<div class="overlay-caption hidden bottom align-left">';
				if ($title) { $output .= '<span class="caption-sub team-role">'.$title.'</span>'; }
				if ($name) { $output .= '<h3 class="caption-name team-name"><strong>'.$name.'</strong></h3>'; }
			$output .= '</div>'.$social;
		} else if ($name || $title || $content) {
			$output .= '<div class="team-infos">';
				if ($title) { $output .= '<span class="team-role">'.$title.'</span>'; }
				if ($name) { $output .= '<h3 class="team-name"><strong>'.$name.'</strong></h3>'; }
				if ($content) { $output .= preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content));  }
			$output .= $social.'</div>';
		}
		
		if ($layout == 'onhover') { $output .= '</div>'; }
	$output .= '</div>'; 
	
	return $output;
}
add_shortcode('sr-teammember', 'dani_teammember');



/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Gallery
/*-----------------------------------------------------------------------------------*/
function dani_gallery( $atts, $content = null )
{
	extract( shortcode_atts( array(
      'medias' => '',
      'type' => '3',
      'masonry' => '1',
      'spacing' => 'isotope-spaced',
      'lightbox' => '0',
      'caption' => '0',
      'unveil' => 'do-anim',
      'lazy' => '1',
      'crop' => '1',
      'galid' => '1'
      ), $atts ) );
		
	static $gId = 1;
	
	$output = '';
	if ($medias) {
		if (!$masonry) { $fitrows = 'fitrows'; } else { $fitrows = ''; }
		$output .= '<div id="sc-gallery-grid'.$gId.'" class="isotope-grid gallery-container style-column-'.$type.' '.$spacing.' '.$fitrows.' clearfix">';
		
		$images = explode(',',$medias);
		foreach($images as $j) {
			$output .= '<div class="isotope-item sr-gallery-item '.$unveil.'">';
			
			if ($lightbox) {
				$imageLightbox = wp_get_attachment_image_src( $j, 'full' );
				$addToImage = ''; if ($caption) { $addToImage = 'data-caption="'.esc_html(get_post($j)->post_excerpt).'"'; }
				$output .= '<a href="'.esc_url($imageLightbox[0]).'" data-rel="lightcase:folio-sc'.$galid.'" class="thumb-hover overlay-effect" '.$addToImage.'>';
			}
			
			if ($type !== 'list') {
				if ($masonry) {
					if ($type == '2') { $image = wp_get_attachment_image_src( $j, 'dani-thumb-medium' ); }
					else if ($type == '3') { $image = wp_get_attachment_image_src( $j, 'dani-thumb-medium' ); }
					else if ($type == '4') { $image = wp_get_attachment_image_src( $j, 'dani-thumb-small' ); }
				} else {
					if ($type == '2') { $image = wp_get_attachment_image_src( $j, 'dani-thumb-big-crop' ); }
					else if ($type == '3') { $image = wp_get_attachment_image_src( $j, 'dani-thumb-medium-crop' ); }
					else if ($type == '4') { $image = wp_get_attachment_image_src( $j, 'dani-thumb-small-crop' ); }
				}
			}
			else { 
				if ($crop) { $image = wp_get_attachment_image_src( $j, 'dani-thumb-ultra' ); }
				else { $image = wp_get_attachment_image_src( $j, 'full' ); }
			}
				
			if ($lazy) {
			$output .= '<img class="lazy" data-src="'.esc_url($image[0]).'" width="'.esc_attr($image[1]).'" height="'.esc_attr($image[2]).'" alt="'.esc_html(get_the_title($j)).'" />';	
			} else {
			$output .= '<img src="'.esc_url($image[0]).'" width="'.esc_attr($image[1]).'" height="'.esc_attr($image[2]).'" alt="'.esc_html(get_the_title($j)).'" />';	
			}
			
			if ($lightbox) { $output .= '</a>'; }
			$output .= '</div>';
			
		}
		
		$output .= '</div>';
	}
	
	$gId++;
	return $output;
	
}
add_shortcode('sr-gallery', 'dani_gallery');



/*-----------------------------------------------------------------------------------*/
/*	Blog Posts Shortcode
/*-----------------------------------------------------------------------------------*/
function dani_blogposts( $atts, $content = null )
{
	
	extract( shortcode_atts( array(
      'show' => 'all',
      'category' => '',
      'style' => 'masonry',
      'columns' => '3',
      'count' => '6',
      'readmore' => '1',
      'date' => '1',
      'category' => '1'
      ), $atts ) );
	
	
	$gridClass = 'blog-container classic-blog';
	$gridTemplate = 'default';
	if ($style == 'masonry') { $gridClass = 'isotope-grid style-column-'.$columns.' isotope-spaced-big'; $gridTemplate = 'default'; } else
	if ($style == 'minimal-grid') { $gridClass = 'isotope-grid minimal-grid-blog style-column-'.$columns.' fitrows'; $gridTemplate=$style;} else
	if ($style == 'minimal-list') { $gridClass = 'minimal-list-blog'; $gridTemplate=$style; }
	
	if ($show == 'all') { $terms = wp_list_pluck( get_terms('category'), 'term_id' ); }
	else if ($category) { $terms = explode(',',$category); } else { $terms = false; }
	$taxquery = array(	array( 'taxonomy' => 'category', 'field' => 'term_id', 'terms' => $terms ));
	
	$query = new WP_Query(array(
		'post_type' => array('post'),
		'posts_per_page'=> $count,
		'tax_query' => $taxquery
	));
	
	ob_start();
	
	if ( $query->have_posts() ) { 
		echo '<div id="blog-grid" class="'.esc_attr($gridClass).'">';
        	while ($query->have_posts()) { $query->the_post();
				include( locate_template( 'includes/loop-blog-'.$gridTemplate.'.php' ) );
			}
        echo '</div>';
		wp_reset_postdata();
	} // END if have posts
	
	return ob_get_clean();
	
}
add_shortcode('sr-blogposts', 'dani_blogposts');




/*-----------------------------------------------------------------------------------*/
/*	Portfolio Items Shortcode
/*-----------------------------------------------------------------------------------*/
function dani_portfolioitems( $atts, $content = null )
{
	
	extract( shortcode_atts( array(
      'gridwidth' => 'wrapper',
      'gridtype' => 'isotope',
      'gridmasonrycol' => '3',
      'gridmasonry' => '1',
      'gridsmartcol' => '2',
      'gridspaced' => 'spaced',
      'gridunveil' => 'portfolio-animation',
      'filtershow' => 'all',
      'filtercategory' => '',
      'filtercount' => '12',
      'filterenable' => '1',
      'filteralignment' => 'align-left',
      'pagination' => '0',
      'captionforce' => '0',
      'hovercaption' => 'onhover',
      'captionsize' => 'h4',
      'captionposition' => 'bottom',
      'captionalignment' => 'align-left',
      'captioncategory' => '1',
      'captioncolor' => 'align-left',
      'hovercolor' => 'overlay-effect',
      'captionarrow' => '1',
      'paged' => ''
      ), $atts ) );
	
	static $pId = 1;
	
	if ($gridtype == 'isotope') {
		$gridClass = 'isotope-grid isotope-'.$gridspaced.' style-column-'.$gridmasonrycol.' '.$gridunveil;
		if (!$gridmasonry) { $gridClass .= ' fitrows';}
		$gridAdd = '';
	} else if ($gridtype == 'smartscroll') {
		$gridClass = 'smartscroll-grid smartscroll-'.$gridspaced.' '.$gridunveil;
		$gridAdd = 'data-columns="'.$gridsmartcol.'"';
	}
	
	ob_start();
		
	if ( get_option( 'page_on_front' ) == get_the_ID() ) { $pagenumber = ( get_query_var('page') ? get_query_var('page') : 1 ); } 
	else { $pagenumber = ( get_query_var('paged') ? get_query_var('paged') : 1 ); }
	if ($paged) { $pagenumber = $paged; }
	
	if ($filtershow == 'all') { $terms = wp_list_pluck( get_terms('portfolio_category'), 'term_id' ); }
	else if ($filtercategory) { $terms = explode(',',$filtercategory); } else { $terms = false; }
	$taxquery = array(	array( 'taxonomy' => 'portfolio_category', 'field' => 'term_id', 'terms' => $terms ));
				
	$query = new WP_Query(array(
		'posts_per_page'=> $filtercount,
		'paged' => $pagenumber,
		'm' => get_query_var('m'),		   
		'w' => get_query_var('w'),
		'post_type' => array('portfolio'),
		'tax_query' => $taxquery
	));
	
	if ( $query->have_posts() ) { 
		
		$maxPages = $query->max_num_pages;
		
		if ($gridwidth == 'wrapper' || $gridwidth == 'wrapper-big') { echo '<div class="'.$gridwidth.'">'; }
		
		if ($filterenable && $terms && $gridtype == 'isotope') { 
			if ($gridwidth == 'no-wrapper') { echo '<div class="wrapper">'; }
        	dani_filter('portfolio-filter',$filteralignment,'portfolio-grid'.$pId,$terms);
			if ($gridwidth == 'no-wrapper') { echo '</div>'; }
        }
		
		echo '<div id="portfolio-grid'.esc_attr($pId).'" class="'.esc_attr($gridClass).' portfolio-container" '.$gridAdd.'>';
        	while ($query->have_posts()) { $query->the_post();
				include( locate_template( 'includes/loop-portfolio.php' ) );
			}
        echo '</div>';
		
		if ($maxPages > 1 && !$paged) {
			if ($pagination == 'pagination') { 
				echo '<div id="page-pagination">'
					.dani_pagination('portfolio',esc_html__( 'Previous Page', 'dani' ), esc_html__( 'Next Page', 'dani' ),$query)
				.'</div>'; 
			} else if (($pagination == 'loadonclick' || $pagination == 'infiniteload') && $gridtype == 'isotope') {
				$options = str_replace("&", "|", http_build_query($atts));
				$options = $options.'|paged=2|';
				echo '
				<div class="load-isotope align-center">
					<a 	href="#" class="sr-button" 
						data-related-grid="portfolio-grid'.esc_attr($pId).'" 
						data-method="'.$pagination.'"
						data-options="'.$options.'"
						>'.esc_html__( 'Load More', 'dani' ).'</a>
					<span class="load-message">'.esc_html__( 'No more items to show', 'dani' ).'</span>
				</div>';	
			}
		}
		
		if ($gridwidth == 'wrapper' || $gridwidth == 'wrapper-big') { echo '</div> <!-- END .wrapper -->'; }
			
		wp_reset_postdata();
	} // END if have posts
	
	$pId++;
	return ob_get_clean();
	
}
add_shortcode('sr-portfolioitems', 'dani_portfolioitems');




/*-----------------------------------------------------------------------------------*/
/*	Shop Items Shortcode
/*-----------------------------------------------------------------------------------*/
function dani_shopitems( $atts, $content = null )
{
	
	extract( shortcode_atts( array(
      'gridwidth' => 'wrapper',
      'gridtype' => 'isotope',
      'gridmasonrycol' => '3',
      'gridsmartcol' => '2',
      'gridspaced' => 'spaced',
      'count' => '4',
      'pagination' => '0',
      'layoutcustom' => 'inherit',
      'itemlayout' => 'below',
      'showinfos' => 'onstart',
      'itemhover' => 'text-dark',
      'itemhovercustom' => '',
      'titlesize' => 'h5',
      'showprice' => '1',
      'showaddtocart' => '1',
      'showsale' => '1',
	  'filtershow' => 'all',
      'filtercategory' => '',
      'filterorder' => 'date',
      'filtersort' => 'DESC',
      'paged' => ''
      ), $atts ) );
	
	static $sId = 1;
	
	if ($gridtype == 'isotope') {
		$gridClass = 'isotope-grid isotope-'.$gridspaced.' style-column-'.$gridmasonrycol;
		$gridClass .= ' fitrows';
		$gridAdd = '';
	} else if ($gridtype == 'smartscroll') {
		$gridClass = 'smartscroll-grid smartscroll-'.$gridspaced;
		$gridAdd = 'data-columns="'.$gridsmartcol.'"';
	}
	
	ob_start();
		
	if ( get_option( 'page_on_front' ) == get_the_ID() ) { $pagenumber = ( get_query_var('page') ? get_query_var('page') : 1 ); } 
	else { $pagenumber = ( get_query_var('paged') ? get_query_var('paged') : 1 ); }
	if ($paged) { $pagenumber = $paged; }
	
	if ($filtershow == 'all') { $terms = wp_list_pluck( get_terms('product_cat'), 'term_id' ); }
	else if ($filtercategory) { $terms = explode(',',$filtercategory); } else { $terms = false; }
	$taxquery = array(	array( 'taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $terms ));
					
	$query = new WP_Query(array(
		'posts_per_page'=> $count,
		'paged' => $pagenumber,
		'm' => get_query_var('m'),		   
		'w' => get_query_var('w'),
		'post_type' => array('product'),
		'tax_query' => $taxquery,
		'orderby'   => $filterorder,
		'order'   => $filtersort,
		
		// do not load the hidden products
		'meta_query' => array(
			array(
				'key'       => '_visibility',
				'value'     => 'hidden',
				'compare'   => '!=',
			)
		)
	));
	
	if ( $query->have_posts() ) { 
		
		$maxPages = $query->max_num_pages;
		
		if ($gridwidth) { echo '<div class="'.$gridwidth.'">'; }
		echo '<div id="shop-grid'.esc_attr($sId).'" class="'.esc_attr($gridClass).' shop-container" '.$gridAdd.'>';
        	while ($query->have_posts()) { $query->the_post();
				include( locate_template( 'woocommerce/content-product.php' ) );
			}
        echo '</div>';
		
		if ($maxPages > 1 && !$paged) {
			if ($pagination == 'pagination') { 
				echo '<div id="page-pagination">'
					.dani_pagination('shop',esc_html__( 'Previous Page', 'dani' ), esc_html__( 'Next Page', 'dani' ),$query)
				.'</div>'; 
			} else if ($pagination == 'loadonclick' || $pagination == 'infiniteload') {
				$options = str_replace("&", "|", http_build_query($atts));
				$options = $options.'|paged=2|';
				echo '
				<div class="load-isotope align-center">
					<a 	href="#" class="sr-button" 
						data-related-grid="shop-grid'.esc_attr($sId).'" 
						data-method="'.$pagination.'"
						data-options="'.$options.'"
						>'.esc_html__( 'Load More', 'dani' ).'</a>
					<span class="load-message">'.esc_html__( 'No more items to show', 'dani' ).'</span>
				</div>';	
			}
		}
		
		if ($gridwidth) { echo '</div> <!-- END .wrapper -->'; }
			
		wp_reset_postdata();
	} // END if have posts
	
	$sId++;
	return ob_get_clean();
	
}
add_shortcode('sr-shopitems', 'dani_shopitems');



/*-----------------------------------------------------------------------------------*/
/*	Shortcodes for Google Map
/*-----------------------------------------------------------------------------------*/
function dani_googlemap_shortcode( $atts, $content = null )
{
	extract( shortcode_atts( array(
      'latlong' => '-33.86938,151.204834',
      'apikey' => '',
      'pinicon' => get_template_directory_uri().'/files/images/map-pin.png',
      'height' => '400',
      'zoom' => '14',
      'style' => 'default'
      ), $atts ) );
	
	$text = preg_replace('#^<\/p>|<p>$#', '', do_shortcode($content));
	
	if ($height) { $mapStyle= 'height:'.esc_attr($height).';'; } else { $mapStyle = 'height:400px;'; }
	return dani_googleMap($latlong, $text, $pinicon, $mapStyle, '', '', $style, $apikey, $zoom);
		
}
add_shortcode('sr-googlemap', 'dani_googlemap_shortcode');


/*-----------------------------------------------------------------------------------*/
/*	Wordpress Bugfix for shortcodes (paragraph issue)
/*-----------------------------------------------------------------------------------*/
add_filter("the_content", "dani_pb_content_filter");
function dani_pb_content_filter($content) {
 
	// array of custom shortcodes requiring the fix
	$block = join("|",array(	
							"col",
							"columnsection",
							"fullwidthsection",
							"sr-spacer",
							"sr-googlemap",
							"sr-teammember",
							"sr-gallery",
							"sr-blogposts"
							));
	 
	// opening tag
	$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
	// closing tag
	$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
	return $rep;
 
}


?>