<?php

/*-----------------------------------------------------------------------------------

	Custom Post/Portfolio Meta boxes

-----------------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------------*/
/*	Add Pagebuilder Metabox
/*-----------------------------------------------------------------------------------*/

function dani_add_meta_pagebuilder() {  
    add_meta_box(  
        'meta_pagebuilder', // $id  
        esc_html__('Pagebuilder', 'dani'), // $title  
        'dani_show_meta_pagebuilder', // $callback  
        'page', // $page  
        'normal', // $context  
        'high'); // $priority
		
	add_meta_box(  
        'meta_pagebuilder', // $id  
        esc_html__('Pagebuilder', 'dani'), // $title  
        'dani_show_meta_pagebuilder', // $callback  
        'portfolio', // $page  
        'normal', // $context  
        'high'); // $priority		
}  
add_action('add_meta_boxes', 'dani_add_meta_pagebuilder');

	

/*-----------------------------------------------------------------------------------*/
/*	Pagebuilder (Options)
/*-----------------------------------------------------------------------------------*/
$dani_meta_pagebuilder = array(  
	array(  
		'title' => esc_html__('Background Section', 'dani'),
	   	'id'    => 'fullwidthsection',
	   	'desc' => '',
	   	'type' => 'row',
	   	'icon' => 'dashicons-admin-customizer',
		'fields' => array(
			
			array( "name" => esc_html__("Settings", 'dani'),
			   "id" => "sr-pb-tab-bgsettings",
			   "type" => "tabstart"
			  ),
			
				array(
					'label' => esc_html__('Background', 'dani'),
					'desc' => '',
					'id' => 'background',
					'type' => 'selectbox-hiding',
					'sendval' => true,
					'option' => array( 
						array(	'name' =>esc_html__('Color Background', 'dani'), 
								'value' => 'color'),			 	
						array(	'name' => esc_html__('Image / Parallax Background', 'dani'), 
								'value'=> 'image'),
						array(	"name" => esc_html__("Selfhosted Video Background", 'dani'), 
								"value"=> "selfhosted"),
						array(	"name" => esc_html__("Youtube Video Background", 'dani'), 
								"value"=> "youtube"),
						array(	"name" => esc_html__("Vimeo Video Background", 'dani'), 
								"value"=> "vimeo")
						),
					'default' => 'color'
				),
				
					// Color Background
					array( 
							"id" => "fullwidthsection-background",
							"hiding" => "color",	
							"type" => "hidinggroupstart"
						),
						array( 	"label" => esc_html__("Background Color", 'dani'),
								"desc" => 'Choose a background color for this row',
								"id" => 'colorbg',
								"type" => "color",
								'sendval' => true
						),
					array( 
							"id" => "fullwidthsection-background",
							"type" => "hidinggroupend"
						),
						
						
					// Image Background
					array( 
							"id" => "fullwidthsection-background",
							"hiding" => "image",	
							"type" => "hidinggroupstart"
						),
						array(  'label' => esc_html__("Background Image", 'dani'),  
								'desc'  => "",  
								'id'    => 'imagebg',  
								'type'  => 'image', 
								'sendval' => true
						),
						array(  'label' => esc_html__("Image type (effect)", 'dani'),  
								'desc'  => "",  
								'id'    => 'imagetype', 
								'type'  => 'checkbox-hiding', 
								'sendval' => true,
								'option' => array( 
									array(	"name" => esc_html__("Parallax", 'dani'), 
											"value" => "parallax"),
									array(	"name" => esc_html__("Normal", 'dani'), 
											"value" => "normal"),
									array(	"name" => esc_html__("Pattern", 'dani'), 
											"value" => "pattern")
									),
								'default'  => 'parallax', 
								),
								
							array( 	"id" => "fullwidthsection-imagetype",
									"hiding" => "pattern",	
									"type" => "hidinggroupstart"
									),
									
									array(  'label' => " ",
											'desc'  => esc_html__("To enable retina for the pattern, you need to upload an image with '@2x' in its name.", 'dani').'<br>'.esc_html__("Example: pattern@2x.jpg.  In this case, the image will be descrease by half of it size.", 'dani'),  
											'type'  => 'info'
											),
									
							array( 	"id" => "fullwidthsection-imagetype",
									"hiding" => "pattern",	
									"type" => "hidinggroupend"
									),
						
					array( 
							"id" => "fullwidthsection-background",
							"type" => "hidinggroupend"
						),	
						
					
					// Selfhosted Video
					array( 
							"id" => "fullwidthsection-background",
							"hiding" => "selfhosted",	
							"type" => "hidinggroupstart"
						),
						array(  'label' => esc_html__("MP4 file url", 'dani'),  
								'desc'  => esc_html__("The url to the MP4 file", 'dani'),  
								'id'    => 'selfhostedmp4',  
								'type'  => 'video', 
								'sendval' => true
							),
						array(  'label' => esc_html__("WEBM file url", 'dani'),  
								'desc'  => esc_html__("The url to the WEBM file", 'dani'),  
								'id'    => 'selfhostedwebm',  
								'type'  => 'video', 
								'sendval' => true
							),
						array(  'label' => esc_html__("OGV file url", 'dani'),  
								'desc'  => esc_html__("The url to the OGV file", 'dani'),  
								'id'    => 'selfhostedogv',  
								'type'  => 'video', 
								'sendval' => true
							),
					array( 
							"id" => "fullwidthsection-background",
							"type" => "hidinggroupend"
						),
						
						
					// Youtube Video
					array( 
							"id" => "fullwidthsection-background",
							"hiding" => "youtube",	
							"type" => "hidinggroupstart"
						),
						array(  'label' => esc_html__("Youtube Video ID", 'dani'),  
								'desc'  => esc_html__("Enter the right of id of the youtube video", 'dani'),  
								'id'    => 'youtubeid',  
								'type'  => 'text', 
								'sendval' => true,
							),
					array( 
							"id" => "fullwidthsection-background",
							"type" => "hidinggroupend"
						),
						
					
					// Vimeo Video
					array( 
							"id" => "fullwidthsection-background",
							"hiding" => "vimeo",	
							"type" => "hidinggroupstart"
						),
						array(  'label' => esc_html__("Vimeo Video ID", 'dani'),  
								'desc'  => esc_html__("Enter the right of id of the vimeo video", 'dani'),  
								'id'    => 'vimeoid',  
								'type'  => 'text', 
								'sendval' => true,
							),
					array( 
							"id" => "fullwidthsection-background",
							"type" => "hidinggroupend"
						),
						
						
					// Misc Video
					array( 
							"id" => "fullwidthsection-background",
							"hiding" => "selfhosted youtube vimeo",	
							"type" => "hidinggroupstart"
						),
						array(  'label' => esc_html__("Video Ratio", 'dani'),  
								'desc'  => "",  
								'id'    => 'videoratio', 
								'type'  => 'selectbox', 
								'sendval' => true,
								'option' => array( 
									array(	"name" => "4/3", 
											"value" => "4/3"),
									array(	"name" => "16/9", 
											"value" => "16/9"),
									array(	"name" => "21/9", 
											"value" => "21/9")
									),
								'default'  => '16/9', 
								),
						array(  'label' => esc_html__("Loop Video", 'dani'),  
								'desc'  => "",  
								'id'    => 'videoloop', 
								'type'  => 'checkbox',
								'sendval' => true,
								'default' => '1'
								),
								
						array(  'label' => esc_html__("Sound", 'dani'),  
								'desc'  => "",  
								'id'    => 'videomute', 
								'type'  => 'checkbox',
								'sendval' => true,
								'option' => array( 
									array(	"name" => "On", 
											"value" => "1"),
									array(	"name" => "Off", 
											"value" => "0")
									),
								'default'  => '0' 
								),
								
						array(  'label' => esc_html__("Video Poster Image", 'dani'),  
								'desc'  => esc_html__("This image will be displayed on mobile devices", 'dani'),  
								'id'    => 'videoposter',  
								'type'  => 'image', 
								'sendval' => true
								),
								
						array(	'label' => esc_html__("Video Overlay Color", 'dani'),  
								'desc'  => "",  
								'id'    => 'videooverlaycolor',  
								'type'  => 'color', 
								'sendval' => true
								),
								
						array(  'label' => esc_html__("Video Overlay opacity", 'dani'),  
								'desc'  => esc_html__("Choose the opacity for the overlay color", 'dani'),  
								'id'    => 'videooverlayopacity', 
								'type'  => 'selectbox', 
								'sendval' => true,
								'option' => array( 
									array(	"name" => "0.1", 
											"value" => "0.1"),
									array(	"name" => "0.2", 
											"value" => "0.2"),
									array(	"name" => "0.3", 
											"value" => "0.3"),
									array(	"name" => "0.4", 
											"value" => "0.4"),
									array(	"name" => "0.5", 
											"value" => "0.5"),
									array(	"name" => "0.6", 
											"value" => "0.6"),
									array(	"name" => "0.7", 
											"value" => "0.7"),
									array(	"name" => "0.8", 
											"value" => "0.8"),
									array(	"name" => "0.9", 
											"value" => "0.9")	
									),
								'default' => '0.1'
							),
					array( 
							"id" => "fullwidthsection-background",
							"type" => "hidinggroupend"
						),	
						
						
					array(
							'label' => esc_html__('Text color', 'dani'),
							'desc' => esc_html__("Choose Text color depending on your background", 'dani'),
							'id' => 'textcolor',
							'type' => 'selectbox',
							'sendval' => true,
							'option' => array( 
								array(	'name' =>esc_html__('Light', 'dani'), 
										'value' => 'text-light'),			 	
								array(	'name' => esc_html__('Dark', 'dani'), 
										'value'=> 'text-dark')
								),
							'default' => 'text-light'
						),
					array( 	"label" => esc_html__("Padding Top", 'dani'),
							"desc" => '',
							"id" => "pdtop",
							"type" => "text",
							'sendval' => true,
							"default" => "100px"
						),
					array( 	"label" => esc_html__("Padding Bottom", 'dani'),
							"desc" => '',
							"id" => "pdbottom",
							"type" => "text",
							'sendval' => true,
							"default" => "100px"
						),
						
			array( "name" => esc_html__("Settings", 'dani'),
			   "id" => "sr-pb-tab-bgsettings",
			   "type" => "tabend"
			  ),
			  
			  
			array( "name" => esc_html__("Customize", 'dani'),
			   "id" => "sr-pb-tab-bgcustomize",
			   "type" => "tabstart"
			  ),
			  
			  	array( 	"label" => esc_html__("Class", 'dani'),
						"desc" => '',
						"id" => "class",
						"type" => "text",
						'sendval' => true,
						"default" => ""
					),
					
				array( 	"label" => esc_html__("ID", 'dani'),
						"desc" => '',
						"id" => "id",
						"type" => "text",
						'sendval' => true,
						"default" => ""
					),
			  
			array( "name" => esc_html__("Customize", 'dani'),
			   "id" => "sr-pb-tab-bgcustomize",
			   "type" => "tabend"
			  ),
			
		)
	),
	array(  
		'title' => esc_html__('Column Row', 'dani'),
	   	'id'    => 'columnsection',
	   	'desc' => '',
	   	'type' => 'row',
	   	'icon' => 'dashicons-editor-table',
		'fields' => array(
			
			array( "name" => esc_html__("Column Settings", 'dani'),
			   	"id" => "sr-pb-tab-columnsettings",
			   	"type" => "tabstart"
			  	),
			
				array(
					'label' => esc_html__('Content Size', 'dani'),
					'desc' => 'Choose the wrapper/content size.',
					'id' => 'wrapper',
					'type' => 'selectbox',
					'sendval' => true,
					'option' => array( 
						array(	'name' => esc_html__('Small (780px width)', 'dani'), 
								'value'=> 'wrapper-small'),
						array(	'name' =>esc_html__('Default (1200px width)', 'dani'), 
								'value' => 'wrapper'),
						array(	'name' =>esc_html__('Big (1660px width)', 'dani'), 
								'value' => 'wrapper-big'),
						array(	'name' => esc_html__('Full (100% of window width)', 'dani'), 
								'value'=> 'no-wrapper')
						),
					'default' => 'wrapper'
				),
							
				array(
					'label' => esc_html__('Column Layout', 'dani'),
					'desc' => '',
					'id' => 'layout',
					'type' => 'custom-select',
					'sendval' => true,
					'option' => array( 
						array(	'name' =>esc_html__('Full', 'dani'), 
								'value' => 'one-full',
								'img' => 'col-1.png'),	
						array(	'name' => esc_html__('Half/Half', 'dani'), 
								'value'=> 'one-half;one-half',
								'img' => 'col-2.png'),
						array(	'name' => esc_html__('Third/Third/Third', 'dani'), 
								'value'=> 'one-third;one-third;one-third',
								'img' => 'col-3.png'),
						array(	'name' => esc_html__('Fourth/Fourth/Fourth/Fourth', 'dani'), 
								'value'=> 'one-fourth;one-fourth;one-fourth;one-fourth',
								'img' => 'col-4.png'),
						array(	'name' => esc_html__('Fifth/Fifth/Fifth/Fifth/Fifth', 'dani'), 
								'value'=> 'one-fifth;one-fifth;one-fifth;one-fifth;one-fifth',
								'img' => 'col-5.png'),
						array(	'name' => esc_html__('One Thrid/Two Third', 'dani'), 
								'value'=> 'one-third;two-third',
								'img' => 'col-6.png'),
						array(	'name' => esc_html__('Two Thrid/One Third', 'dani'), 
								'value'=> 'two-third;one-third',
								'img' => 'col-7.png'),
						array(	'name' => esc_html__('One Fourth/Three Fourth', 'dani'), 
								'value'=> 'one-fourth;three-fourth',
								'img' => 'col-8.png'),
						array(	'name' => esc_html__('Three Fourth/One Fourth', 'dani'), 
								'value'=> 'three-fourth;one-fourth',
								'img' => 'col-9.png'),
						array(	'name' => esc_html__('One Fourth/One Fourth/Two Fourth', 'dani'), 
								'value'=> 'one-fourth;one-fourth;two-fourth',
								'img' => 'col-10.png'),
						array(	'name' => esc_html__('Two Fourth/One Fourth/One Fourth', 'dani'), 
								'value'=> 'two-fourth;one-fourth;one-fourth',
								'img' => 'col-11.png'),
						array(	'name' => esc_html__('One Fourth/Two Fourth/One Fourth', 'dani'), 
								'value'=> 'one-fourth;two-fourth;one-fourth',
								'img' => 'col-12.png')	
						),
					'default' => 'one-full'
				),
				
				array(
					'label' => esc_html__('Column Spacing', 'dani'),
					'desc' => 'Choose a spacing size for this column grid.',
					'id' => 'spacing',
					'type' => 'selectbox',
					'sendval' => true,
					'option' => array( 
						array(	'name' => esc_html__('Normal / Default', 'dani'), 
								'value'=> 'spaced-normal'),
						array(	'name' =>esc_html__('Big spacings', 'dani'), 
								'value' => 'spaced-big')
						),
					'default' => 'spaced-normal'
				),
			  
			array( "name" => esc_html__("Column Settings", 'dani'),
			   "id" => "sr-pb-tab-columnsettings",
			   "type" => "tabend"
			  ),
			
			
			array( "name" => esc_html__("Customize", 'dani'),
			   "id" => "sr-pb-tab-columncustomize",
			   "type" => "tabstart"
			  ),
			  
			  	array( 	"label" => esc_html__("Class", 'dani'),
						"desc" => '',
						"id" => "class",
						"type" => "text",
						'sendval' => true,
						"default" => ""
					),
					
				array( 	"label" => esc_html__("ID", 'dani'),
						"desc" => '',
						"id" => "id",
						"type" => "text",
						'sendval' => true,
						"default" => ""
					),
			  
			array( "name" => esc_html__("Customize", 'dani'),
			   "id" => "sr-pb-tab-columncustomize",
			   "type" => "tabend"
			  ),
					
		)
	),
	array(  
		'title' => __('Column Settings', 'sr_dani_theme'),
	   	'id'    => 'col',
	   	'desc' => '',
	   	'type' => 'hidden',
	   	'icon' => 'dashicons-admin-settings',
		'fields' => array(
			
			array( "name" => __("Background", 'sr_dani_theme'),
			   "id" => "sr-pb-tab-colbackground",
			   "type" => "tabstart"
			  ),	
			  
			  	array(
					'label' => __('Background', 'sr_dani_theme'),
					'desc' => '',
					'id' => 'background',
					'type' => 'selectbox-hiding',
					'sendval' => true,
					'option' => array( 
						array(	'name' =>__('None', 'sr_dani_theme'), 
								'value' => 'none'),	
						array(	'name' =>__('Color Background', 'sr_dani_theme'), 
								'value' => 'color'),			 	
						array(	'name' => __('Image / Parallax Background', 'sr_dani_theme'), 
								'value'=> 'image')
						),
					'default' => 'none'
				),
				
					// Color Background
					array( 
							"id" => "col-background",
							"hiding" => "color",	
							"type" => "hidinggroupstart"
						),
						array( 	"label" => __("Background Color", 'sr_dani_theme'),
								"desc" => 'Choose a background color for this row',
								"id" => 'colorbg',
								"type" => "color",
								'sendval' => true
						),
					array( 
							"id" => "col-background",
							"type" => "hidinggroupend"
						),
						
						
					// Image Background
					array( 
							"id" => "col-background",
							"hiding" => "image",	
							"type" => "hidinggroupstart"
						),
						array(  'label' => __("Background Image", 'sr_dani_theme'),  
								'desc'  => "",  
								'id'    => 'imagebg',  
								'type'  => 'image', 
								'sendval' => true
						),
						array(  'label' => __("Image type (effect)", 'sr_dani_theme'),  
								'desc'  => "",  
								'id'    => 'imagetype', 
								'type'  => 'checkbox-hiding', 
								'sendval' => true,
								'option' => array( 
									array(	"name" => __("Parallax", 'sr_dani_theme'), 
											"value" => "parallax"),
									array(	"name" => __("Normal", 'sr_dani_theme'), 
											"value" => "normal"),
									array(	"name" => __("Pattern", 'sr_dani_theme'), 
											"value" => "pattern")
									),
								'default'  => 'parallax', 
								),
					array( 
							"id" => "col-background",
							"type" => "hidinggroupend"
						),
					
					array(
							'label' => __('Text color', 'sr_dani_theme'),
							'desc' => __("Choose Text color depending on your background", 'sr_dani_theme'),
							'id' => 'textcolor',
							'type' => 'selectbox',
							'sendval' => true,
							'option' => array( 
								array(	'name' => __('Dark', 'sr_dani_theme'), 
										'value'=> 'text-dark'),
								array(	'name' =>__('Light', 'sr_dani_theme'), 
										'value' => 'text-light')			 	
								),
							'default' => 'text-dark'
						),
			  
			array( "name" => __("Background", 'sr_dani_theme'),
			   "id" => "sr-pb-tab-colbackground",
			   "type" => "tabend"
			  ),
			  			
			array( "name" => __("Settings", 'sr_dani_theme'),
			   "id" => "sr-pb-tab-colsettings",
			   "type" => "tabstart"
			  ),	
			
				array(
					'label' => __('Column Size', 'sr_dani_theme'),
					'desc' => '',
					'id' => 'size',
					'type' => 'hidden',
					'sendval' => true/*,
					'option' => array( 
						array(	'name' =>__('Full', 'sr_dani_theme'), 
								'value' => 'one-full'),	
						array(	'name' => __('1/2', 'sr_dani_theme'), 
								'value'=> 'one-half'),
						array(	'name' => __('1/3', 'sr_dani_theme'), 
								'value'=> 'one-third'),
						array(	'name' => __('2/3', 'sr_dani_theme'), 
								'value'=> 'two-third'),
						array(	'name' => __('1/4', 'sr_dani_theme'), 
								'value'=> 'one-fourth'),
						array(	'name' => __('3/4', 'sr_dani_theme'), 
								'value'=> 'three-fourth'),
						array(	'name' => __('1/5', 'sr_dani_theme'), 
								'value'=> 'one-fifth'),
						array(	'name' => __('2/5', 'sr_dani_theme'), 
								'value'=> 'two-fifth'),
						array(	'name' => __('3/5', 'sr_dani_theme'), 
								'value'=> 'three-fifth'),
						array(	'name' => __('4/5', 'sr_dani_theme'), 
								'value'=> 'four-fifth')	
						),
					'default' => 'one-full'*/
				),
				
				array(
					'label' => __('Last Column', 'sr_dani_theme'),
					'desc' => 'Is this the last column of the row?',
					'id' => 'last',
					'type' => 'hidden',
					'sendval' => true/*,
					'option' => array( 
						array(	'name' =>__('No', 'sr_dani_theme'), 
								'value' => 'no-last'),	
						array(	'name' => __('Yes', 'sr_dani_theme'), 
								'value'=> 'last-col')	
						),
					'default' => 'no-last'*/
				),
				
				array(
					'label' => __('Horizontal Padding', 'sr_dani_theme'),
					'desc' => '',
					'id' => 'xpadding',
					'type' => 'text',
					'sendval' => true,
					'default' => '0px'
				),
				
				array(
					'label' => __('Vertical Padding', 'sr_dani_theme'),
					'desc' => '',
					'id' => 'ypadding',
					'type' => 'text',
					'sendval' => true,
					'default' => '0px'
				),
				
				array( 	"label" => __("Class", 'sr_dani_theme'),
						"desc" => '',
						"id" => "class",
						"type" => "text",
						'sendval' => true,
						"default" => ""
					),
					
				array( 	"label" => __("ID", 'sr_dani_theme'),
						"desc" => '',
						"id" => "id",
						"type" => "text",
						'sendval' => true,
						"default" => ""
					),
				
			array( "name" => __("Settings", 'sr_dani_theme'),
			   "id" => "sr-pb-tab-colsettings",
			   "type" => "tabend"
			  )
		)
	),
	array(  
		'title' => esc_html__('Spacer', 'dani'),
	   	'id'    => 'sr-spacer',
	   	'desc' => '',
	   	'type' => 'row,element',
	   	'icon' => 'dashicons-sort',
		'fields' => array(
		
			array(
				'label' => esc_html__('Spacer Size', 'dani'),
				'desc' => 'What spacer size do you want.',
				'id' => 'size',
				'type' => 'selectbox',
				'sendval' => true,
				'option' => array( 
					array(	'name' =>esc_html__('Big (100px)', 'dani'), 
							'value' => 'big'),	
					array(	'name' => esc_html__('Medium (50px)', 'dani'), 
							'value'=> 'medium'),
					array(	'name' => esc_html__('Small (25px)', 'dani'), 
							'value'=> 'small'),
					array(	'name' => esc_html__('Mini (15px)', 'dani'), 
							'value'=> 'mini')	
					),
				'default' => 'big'
			)
		
		)
		
	),
	array(  
		'title' => esc_html__('Text / Editor', 'dani'),
	   	'id'    => 'text',
	   	'desc' => '',
	   	'type' => 'row,element',
	   	'icon' => 'dashicons-editor-alignleft',
		'fields' =>  array(
		
			array(
				'label' => '',
				'desc' => '',
				'id' => 'content',
				'type' => 'editor',
				'sendval' => true
			)
		
		)
	),
	
	array(  
		'title' => esc_html__('Google Map', 'dani'),
	   	'id'    => 'sr-googlemap',
	   	'desc' => '',
	   	'type' => 'row,element',
	   	'icon' => 'dashicons-location',
		'fields' => array(
		
			array(
				'label' => esc_html__("Your API Key", 'dani'),  
				'desc'  => "Since June 2016 you need to create an API Key",  
				'id' => 'apikey',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Latitude & Longitude", 'dani'),  
				'desc'  => esc_html__("Enter the google map latitude & longitude seperated by a comma using this tool: http://itouchmap.com/latlong.html", 'dani'),  
				'id' => 'latlong',
				'type' => 'text',
				'sendval' => true
			),
						
			array(
				'label' => 'Popup Text',
				'desc' => '',
				'id' => 'content',
				'type' => 'editor',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Pin Icon", 'dani'),  
				'desc'  => "",  
				'id' => 'pinicon',
				'type' => 'image',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Height (optional)", 'dani'),  
				'desc'  => "Default is 400px.",  
				'id' => 'height',
				'type' => 'text',
				'sendval' => true,
				'default' => '400px'
			),
			
			array(
				'label' => esc_html__("Zoom", 'dani'),  
				'desc'  => "",  
				'id' => 'zoom',
				'type' => 'text',
				'sendval' => true,
				'default' => '14'
			),
			
			array(
				'label' => esc_html__('Map Style', 'dani'),
				'desc' => '',
				'id' => 'style',
				'type' => 'selectbox',
				'sendval' => true,
				'option' => array( 
					array(	'name' =>esc_html__('Default', 'dani'), 
							'value' => 'default'),			 	
					array(	'name' => esc_html__('Greyscale', 'dani'), 
							'value'=> 'greyscale'),
					array(	'name' => esc_html__('Satelite', 'dani'), 
							'value'=> 'satelite')
					),
				'default' => 'default'
			)
			
		)
	),
	array(  
		'title' => esc_html__('Team Member', 'dani'),
	   	'id'    => 'sr-teammember',
	   	'desc' => '',
	   	'type' => 'element',
	   	'icon' => 'dashicons-admin-users',
		'fields' =>  array(
		
			array(
				'label' => esc_html__("Name", 'dani'),  
				'desc'  => "",  
				'id' => 'name',
				'type' => 'text',
				'sendval' => true
			),
			array(
				'label' => esc_html__("Title / Role", 'dani'),  
				'desc'  => "",  
				'id' => 'title',
				'type' => 'text',
				'sendval' => true
			),
			array(
				'label' => esc_html__("Image", 'dani'),  
				'desc'  => "",  
				'id' => 'image',
				'type' => 'image',
				'sendval' => true
			),			
			array(
				'label' => esc_html__('Layout', 'dani'),
				'desc' => "",
				'id' => 'layout',
				'type' => 'selectbox-hiding',
				'sendval' => true,
				'option' => array( 
					array(	'name' =>esc_html__('Show infos on hover', 'dani'), 
							'value' => 'onhover'),			 	
					array(	'name' => esc_html__('Show infos below image', 'dani'), 
							'value'=> 'belowimage')
					),
				'default' => 'onhover',
			),
			
				array( 
						"id" => "sr-teammember-layout",
						"hiding" => "belowimage",	
						"type" => "hidinggroupstart"
					),
					array(
						'label' => '',
						'desc' => '',
						'id' => 'content',
						'type' => 'editor',
						'sendval' => true
					),
				array( 
						"id" => "sr-teammember-layout",
						"hiding" => "belowimage",	
						"type" => "hidinggroupend"
					),
			
			array(
				'label' => esc_html__("Facebook Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'facebook',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Behance Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'behance',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Dribbble Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'dribbble',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Twitter Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'twitter',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Google Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'google',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Instagram Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'instagram',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Youtube Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'youtube',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Vimeo Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'vimeo',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Tumblr Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'tumblr',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("LinkedIn Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'linkedin',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("VK Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'vk',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Soundcloud Profile", 'dani'),  
				'desc'  => "",  
				'id' => 'soundcloud',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Website link", 'dani'),  
				'desc'  => "make sure to start with http://",  
				'id' => 'website',
				'type' => 'text',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__("Mail Adress", 'dani'),  
				'desc'  => "just enter the email adress",  
				'id' => 'mail',
				'type' => 'text',
				'sendval' => true
			)
		)
	),
	array(  
		'title' => esc_html__('Gallery', 'dani'),
	   	'id'    => 'sr-gallery',
	   	'desc' => '',
	   	'type' => 'row,element',
	   	'icon' => 'dashicons-format-gallery',
		'fields' =>  array(
		
			array(
				'label' => esc_html__("Images", 'dani'),  
				'desc'  => "",  
				'id' => 'medias',
				'type' => 'medias',
				'sendval' => true
			),
			
			array(
				'label' => esc_html__('Gallery type', 'dani'),
				'desc' => '',
				'id' => 'type',
				'type' => 'selectbox-hiding',
				'sendval' => true,
				'option' => array( 
					array(	"name" => esc_html__("List (1 image per row)", 'dani'), 
							"value"=> "list"),		 
					array(	"name" => esc_html__("Gallery with 2 columns", 'dani'), 
							"value" => "2"),
					array(	"name" => esc_html__("Gallery with 3 columns", 'dani'), 
							"value" => "3"),
					array(	"name" => esc_html__("Gallery with 4 columns", 'dani'), 
							"value" => "4")
					),
				"default" => "3"
			),
			
				array( 
						"id" => "sr-gallery-type",
						"hiding" => "2 3 4",	
						"type" => "hidinggroupstart"
					),
					array( "label" => esc_html__("Masonry", 'dani'),
						   "desc" => esc_html__("Images will be showed with original ratios.", 'dani'),
						   "id" => 'masonry',
						   "type" => "checkbox",
						   'sendval' => true,
						   "option" => array( 
								array(	"name" => esc_html__("Yes", 'dani'), 
										"value"=> "1"),		 
								array(	"name" => esc_html__("No", 'dani'), 
										"value" => "0")
								),
							"default" => "1"
						  ),
				array( 
						"id" => "sr-gallery-layout",
						"hiding" => "2 3 4",	
						"type" => "hidinggroupend"
					),
			
			
			array( "label" => esc_html__("Spacing", 'dani'),
				   "desc" => esc_html__("Do you want the image to be spaced?", 'dani'),
				   "id" => "spacing",
				   "type" => "checkbox",
				   'sendval' => true,
				   "option" => array( 
						array(	"name" => esc_html__("Yes", 'dani'), 
								"value"=> "isotope-spaced"),		 
						array(	"name" => esc_html__("No", 'dani'), 
								"value" => "isotope-not-spaced")
						),
					"default" => "isotope-spaced"
				  ),
				  
			array( "label" => esc_html__("Lightbox", 'dani'),
				   "desc" => esc_html__("Do you want to enable the lightbox?", 'dani'),
				   "id" => "lightbox",
				   "type" => "checkbox-hiding",
				   'sendval' => true,
				   "option" => array( 
						array(	"name" => esc_html__("Yes", 'dani'), 
								"value"=> "1"),		 
						array(	"name" => esc_html__("No", 'dani'), 
								"value" => "0")
						),
				   "default" => "0"
				  ),
				  
				array( 
						"id" => "sr-gallery-lightbox",
						"hiding" => "1",	
						"type" => "hidinggroupstart"
					),
					array( "label" => esc_html__("Show Caption", 'dani'),
						   "desc" => esc_html__("Lightbox will show the caption.  Go to your media library and edit/add the caption.", 'dani'),
						   "id" => 'caption',
						   "type" => "checkbox",
						   'sendval' => true,
						   "option" => array( 
								array(	"name" => esc_html__("Yes", 'dani'), 
										"value"=> "1"),		 
								array(	"name" => esc_html__("No", 'dani'), 
										"value" => "0")
								),
							"default" => "0"
						  ),
					array(	'label' => esc_html__("Lightbox", 'dani').' ID',
							'desc' => esc_html__('Thanks to the id you can combine or separate different galleries lightboxes', 'dani'),
							'id' => 'galid',
							'type' => 'selectbox',
							'sendval' => true,
							'option' => array( 
								array(	"name" => "1", 
										"value"=> "1"),		 
								array(	"name" => "2", 
										"value" => "2"),
								array(	"name" => "3", 
										"value" => "3"),
								array(	"name" => "4", 
										"value" => "4"),
								array(	"name" => "5", 
										"value" => "5"),
								array(	"name" => "6", 
										"value" => "6"),
								array(	"name" => "7", 
										"value" => "7"),
								array(	"name" => "8", 
										"value" => "8")
								),
							"default" => "1"
						),
				array( 
						"id" => "sr-gallery-lightbox",
						"hiding" => "1",	
						"type" => "hidinggroupend"
					),
					
				  
			array( "label" => esc_html__("Unveil Effect", 'dani'),
				   "desc" => esc_html__("Enable the slide/fade in effect.", 'dani'),
				   "id" => "unveil",
				   "type" => "checkbox",
				   'sendval' => true,
				   "option" => array( 
						array(	"name" => esc_html__("Yes", 'dani'), 
								"value"=> "do-anim"),		 
						array(	"name" => esc_html__("No", 'dani'), 
								"value" => "no-anim")
						),
				   "default" => "do-anim"
				  ),
				  
			array( "label" => esc_html__("Lazy Load", 'dani'),
				   "desc" => esc_html__("Activate the lazy load for these images.", 'dani'),
				   "id" => "lazy",
				   "type" => "checkbox",
				   'sendval' => true,
				   "option" => array( 
						array(	"name" => esc_html__("Yes", 'dani'), 
								"value"=> "1"),		 
						array(	"name" => esc_html__("No", 'dani'), 
								"value" => "0")
						),
				   "default" => "1"
				  ),
				  
				array( 
						"id" => "sr-gallery-type",
						"hiding" => "list",	
						"type" => "hidinggroupstart"
					),
					array( "label" => esc_html__("Cropping", 'dani'),
						   "desc" => esc_html__("If you plan to have a full screen width image, you should deactivate the cropping.  It will then take the full size of the image.", 'dani'),
						   "id" => 'crop',
						   "type" => "checkbox",
						   'sendval' => true,
						   "option" => array( 
								array(	"name" => esc_html__("Yes", 'dani'), 
										"value"=> "1"),		 
								array(	"name" => esc_html__("No", 'dani'), 
										"value" => "0")
								),
							"default" => "1"
						  ),
				array( 
						"id" => "sr-gallery-layout",
						"hiding" => "list",	
						"type" => "hidinggroupend"
					),			
		)
	),
	
	array(  
		'title' => esc_html__('Blog Posts', 'dani'),
	   	'id'    => 'sr-blogposts',
	   	'desc' => '',
	   	'type' => 'row,element',
	   	'icon' => 'dashicons-admin-post',
		'fields' =>  array(
		
			array(
				'label' => esc_html__("Show Posts", 'dani'),  
				'desc'  => esc_html__("Which posts would you like to show?", 'dani'),  
				'id' => 'show',
				"type" => "selectbox-hiding",
				"sendval" => true,
			   	"option" => array( 
					array(	"name" => esc_html__("Show All Posts", 'dani'), 
							"value"=> "all"),
					array(	"name" => esc_html__("Filter by category", 'dani'), 
							"value"=> "cat")
					),
			   	"default" => "all"
				),
			
				array( 
						"id" => "sr-blogposts-show",
						"hiding" => "cat",	
						"type" => "hidinggroupstart"
						),
					array( 	"label" => esc_html__("Categories", 'dani'),
						   	"desc" => esc_html__("Select the categories you want to display. Select multiple by holding/pressing 'cmd' or 'ctrl'", 'dani'),
						   	"id" => "category",
						   	"type" => "category",
							"sendval" => true,
						   	"option" => "post"
						  	),	
				array( 
						"id" => "sr-blogposts-show",
						"hiding" => "cat",	
						"type" => "hidinggroupend"
						),
		
			array(
				'label' => esc_html__("Blog Style", 'dani'),  
				'desc'  => "",  
				'id' => 'style',
				"type" => "selectbox-hiding",
				"sendval" => true,
			   	"option" => array( 
					array(	"name" => esc_html__("Classic", 'dani'), 
							"value"=> "classic"),
					array(	"name" => esc_html__("Masonry", 'dani'), 
							"value"=> "masonry"),
					array(	"name" => esc_html__("Minimal Grid", 'dani'), 
							"value"=> "minimal-grid"),
					array(	"name" => esc_html__("Minimal List", 'dani'), 
							"value"=> "minimal-list")
					),
			   	"default" => "masonry"
				),
			
				array( 
						"id" => "sr-blogposts-style",
						"hiding" => "masonry minimal-grid",	
						"type" => "hidinggroupstart"
						),
					array( 	"label" => esc_html__("Columns", 'dani'),
						   	"desc" => "",
						   	"id" => 'columns',
						   	"type" => "selectbox",
							"sendval" => true,
							"option" => array( 
								array(	"name" => "2", 
										"value"=> "2"),
								array(	"name" => "3", 
										"value"=> "3"),
								array(	"name" => "4", 
										"value"=> "4")
								),
							"default" => "3"
						  	),
				array( 
						"id" => "sr-blogposts-style",
						"hiding" => "masonry minimal-grid",
						"type" => "hidinggroupend"
						),
					
			array( "label" => esc_html__("Count", 'dani'),
				   "desc" => esc_html__('How many posts to show? Enter "-1" to show all.', 'dani'),
				   "id" => "count",
				   "type" => "text",
					"sendval" => true,
				   "default" => "6"
				  ),	
				  
			array( "label" => esc_html__("Read More Button", 'dani'),
				   "desc" => "",
				   "id" => "readmore",
				   "type" => "checkbox",
					"sendval" => true,
				   "option" => array( 
						array(	"name" => esc_html__("Show", 'dani'), 
								"value"=> "1"),
						array(	"name" => esc_html__("Hide", 'dani'), 
								"value"=> "0")
						),
				   "default" => "1"
				  ),
				  
			array( "label" => esc_html__("Show Date", 'dani'),
				   "desc" => "",
				   "id" => "date",
				   "type" => "checkbox",
					"sendval" => true,
				   "option" => array( 
						array(	"name" => esc_html__("Show", 'dani'), 
								"value"=> "1"),
						array(	"name" => esc_html__("Hide", 'dani'), 
								"value"=> "0")
						),
				   "default" => "1"
				  ),	
				  
			array( "label" => esc_html__("Show Category", 'dani'),
				   "desc" => "",
				   "id" => "category",
				   "type" => "checkbox",
					"sendval" => true,
				   "option" => array( 
						array(	"name" => esc_html__("Show", 'dani'), 
								"value"=> "1"),
						array(	"name" => esc_html__("Hide", 'dani'), 
								"value"=> "0")
						),
				   "default" => "1"
				  ),	
			
		)
	),
	
	array(  
		'title' => esc_html__('Portfolio Grid', 'dani'),
	   	'id'    => 'sr-portfolioitems',
	   	'desc' => '',
	   	'type' => 'row',
	   	'icon' => 'dashicons-portfolio',
		'fields' =>  array(
		
		array( "name" => esc_html__("Grid Options", 'dani'),
			   "id" => "sr-pb-tab-gridoptions",
			   "type" => "tabstart"
			  ),
		
			array( "label" => esc_html__("Grid Width", 'dani'),
				   "desc" => "",
				   "id" => "gridwidth",
				   "type" => "selectbox",
				   "sendval" => true,
				   "option" => array( 
						array(	"name" => esc_html__("Default (1200px)", 'dani'), 
								"value"=> "wrapper"),
						array(	"name" => esc_html__("Big (1660px)", 'dani'), 
								"value"=> "wrapper-big"),
						array(	"name" => esc_html__("Fullwidth", 'dani'), 
								"value" => "no-wrapper")
						),
					"default" => "wrapper"
				  ),
				  
			array( "label" => esc_html__("Grid Type", 'dani'),
				   "desc" => "",
				   "id" => "gridtype",
				   "type" => "selectbox-hiding",
				   "sendval" => true,
				   "option" => array( 
						array(	"name" => esc_html__("Masonry / Grid", 'dani'), 
								"value"=> "isotope"),
						array(	"name" => esc_html__("Smart Scroll", 'dani'), 
								"value" => "smartscroll")
						),
					"default" => "isotope"
				  ),
				  
				array( 	"id" => "sr-portfolioitems-gridtype",
						"hiding" => "isotope",	
						"type" => "hidinggroupstart"
						),
												  
						array( "label" => esc_html__("Columns", 'dani'),
							   "desc" => "",
							   "id" => "gridmasonrycol",
							   "type" => "selectbox",
							   "sendval" => true,
							   "option" => array( 
									array(	"name" => "2", 
											"value"=> "2"),
									array(	"name" => "3", 
											"value" => "3"),
									array(	"name" => "4", 
											"value" => "4")
									),
							   "default" => "3"
							  ),
							  
						array( "label" => esc_html__("Masonry", 'dani'),
							   "desc" => esc_html__("Images will be showed with original ratios.", 'dani'),
							   "id" => "gridmasonry",
							   "type" => "checkbox",
							   "sendval" => true,
							   "option" => array( 
									array(	"name" => esc_html__("Yes", 'dani'), 
											"value"=> "1"),		 
									array(	"name" => esc_html__("No", 'dani'), 
											"value" => "0")
									),
								"default" => "1"
							  ),
												
				array( 	"id" => "sr-portfolioitems-gridtype",
						"hiding" => "isotope",	
						"type" => "hidinggroupend"
						),
						
				array( 	"id" => "sr-portfolioitems-gridtype",
						"hiding" => "smartscroll",	
						"type" => "hidinggroupstart"
						),
						
						array( "label" => esc_html__("Columns", 'dani'),
							   "desc" => "",
							   "id" => "gridsmartcol",
							   "type" => "selectbox-hiding",
							   "sendval" => true,
							   "option" => array( 
									array(	"name" => "2", 
											"value"=> "2"),
									array(	"name" => "3", 
											"value" => "3")
									),
							   "default" => "2"
							  ),					
						
				array( 	"id" => "sr-portfolioitems-gridtype",
						"hiding" => "smartscroll",	
						"type" => "hidinggroupend"
						),
											
				array( "label" => esc_html__("Spacing", 'dani'),
					   "desc" => esc_html__("Do you want the items to be spaced?", 'dani'),
					   "id" => "gridspaced",
					   "type" => "checkbox",
					   "sendval" => true,
					   "option" => array( 
							array(	"name" => esc_html__("Yes", 'dani'), 
									"value"=> "spaced"),		 
							array(	"name" => esc_html__("No", 'dani'), 
									"value" => "not-spaced")
							),
						"default" => "spaced"
					  ),
					  
				array( "label" => esc_html__("Slide In Effect", 'dani'),
					   "desc" => esc_html__("Enable the slide in effect.", 'dani'),
					   "id" => "gridunveil",
					   "type" => "checkbox",
					   "sendval" => true,
					   "option" => array( 
							array(	"name" => esc_html__("Yes", 'dani'), 
									"value"=> "portfolio-animation"),		 
							array(	"name" => esc_html__("No", 'dani'), 
									"value" => "no-anim")
							),
						"default" => "portfolio-animation"
					  ),
					  
				array( 	"label" => esc_html__("Count", 'dani'),
						"desc" => esc_html__('How many posts to show? Enter "-1" to show all.', 'dani'),
						"id" => "filtercount",
						"type" => "text",
						"sendval" => true,
						"default" => "12"
					  ),
					  
				array( 	"id" => "sr-portfolioitems-gridtype",
						"hiding" => "isotope",	
						"type" => "hidinggroupstart"
						),
											
					array( 	"label" => esc_html__("Pagination / Load More", 'dani'),
							"desc" => esc_html__('Do you want to enable any sort of pagination or load more?', 'dani'),
							"id" => "pagination",
							"type" => "selectbox",
							"sendval" => true,
							"option" => array( 
								array(	"name" => esc_html__("No", 'dani'), 
										"value"=> "0"),		 
								array(	"name" => esc_html__("Pagination", 'dani'), 
										"value" => "pagination"),
								array(	"name" => esc_html__("Load More", 'dani'), 
										"value" => "loadonclick"),
								array(	"name" => esc_html__("Infinity Load", 'dani'), 
										"value" => "infiniteload")
								),
								"default" => "0"
						  ),
							
				array( 	"id" => "sr-portfolioitems-gridtype",
						"hiding" => "isotope",	
						"type" => "hidinggroupend"
						),
					  					  
		array( "id" => "sr-pb-tab-gridoptions",
			   "type" => "tabend"
			  ),
			  
			  
			  
		array( "name" => esc_html__("Items & Filter", 'dani'),
			   "id" => "sr-pb-tab-filtergrid",
			   "type" => "tabstart"
			  ),
			  
				array( "label" => esc_html__("Show Items", 'dani'),
					   "desc" => "",
					   "id" => "filtershow",
					   "type" => "selectbox-hiding",
					   "sendval" => true,
					   "option" => array( 
							array(	"name" => esc_html__("Show All items", 'dani'), 
									"value"=> "all"),
							array(	"name" => esc_html__("Select by category", 'dani'), 
									"value"=> "cat")
							),
						"default" => "all"
					  ),
					  
				array( 	"id" => "sr-portfolioitems-filtershow",
						"hiding" => "cat",	
						"type" => "hidinggroupstart"
						),
						
						array( "label" => esc_html__("Categories", 'dani'),
							   "desc" => esc_html__("Select the categories you want to display.  Select multiple by holding/pressing 'cmd' or 'ctrl'", 'dani'),
							   "id" => "filtercategory",
							   "type" => "category",
							   "sendval" => true,
							   "option" => "portfolio"
							  ),
						
				array( 	"id" => "sr-portfolioitems-filtershow",
						"hiding" => "cat",	
						"type" => "hidinggroupend"
						),
					  
				array( "label" => esc_html__("Enable Live Filter", 'dani'),
					   "desc" => '<span class="important">'.esc_html__("The filter is only possible with 'Masonry / Grid' type.  It won't work with 'Smart Scroll' Grid type!", 'dani').'</span>',
					   "id" => "filterenable",
					   "type" => "checkbox-hiding",
					   "sendval" => true,
					   "option" => array( 
							array(	"name" => esc_html__("Yes", 'dani'), 
									"value"=> "1"),		 
							array(	"name" => esc_html__("No", 'dani'), 
									"value" => "0")
							),
						"default" => "1"
					  ),
					array( 	"id" => "sr-portfolioitems-filterenable",
							"hiding" => "1",	
							"type" => "hidinggroupstart"
							),
							array( "label" => esc_html__("Filter Alignment", 'dani'),
								   "desc" => "",
								   "id" => "filteralignment",
								   "type" => "selectbox",
								   "sendval" => true,
								   "option" => array( 
										array(	"name" => esc_html__("Left", 'dani'), 
												"value"=> "align-left"),		 
										array(	"name" => esc_html__("Center", 'dani'), 
												"value" => "align-center"),
										array(	"name" => esc_html__("Right", 'dani'), 
												"value" => "align-right")
										),
									"default" => "align-left"
								  ),
					array( 	"id" => "sr-portfolioitems-filterenable",
							"hiding" => "1",	
							"type" => "hidinggroupend"
							),
			  
		array( "id" => "sr-pb-tab-filtergrid",
			   "type" => "tabend"
			  ),
			  
			  
			  
		array( "name" => esc_html__("Caption & Hover", 'dani'),
			   "id" => "sr-pb-tab-hovereffect",
			   "type" => "tabstart"
			  ),
			  
			 array(  "desc" => '<strong>Note</strong> '.esc_html__("If these settings don't have any effect on your grid items (or some of them), you probably have activated some custom captions settings for these items.  You can force these settings for this grid below.", 'dani'),
					"type"  => "info"  
				),	
			
			  array(  "label" => esc_html__("Force settings", 'dani'),
					"desc" => esc_html__("If yes, your individual custom caption settings won't be respected.", 'dani'),
					"id" => "captionforce",
					"type" => "checkbox-hiding",
					"sendval" => true,
					"option" => array( 
						array(	"name" => esc_html__("No", 'dani'), 
								"value" => "0"),
						array(	"name" => esc_html__("Yes", 'dani'), 
								"value" => "1")
						),
					"default" => "0"
				),
			  
			  array( "label" => esc_html__("Caption Option", 'dani'),
				   "desc" => "",
				   "id" => "hovercaption",
				   "type" => "selectbox-hiding",
				   "sendval" => true,
				   "option" => array( 
						array(	"name" => esc_html__("Show caption on hover", 'dani'), 
								"value"=> "onhover"),
						array(	"name" => esc_html__("Always show caption", 'dani'), 
								"value" => "onstart"),
						array(	"name" => esc_html__("Display caption below the thumb", 'dani'), 
								"value" => "belowthumb"),
						array(	"name" => esc_html__("Hide caption", 'dani'), 
								"value" => "hide")
						),
					"default" => "onhover"
				  ),
				  
				array( 	"id" => "sr-portfolioitems-hovercaption",
						"hiding" => "onhover onstart belowthumb",	
						"type" => "hidinggroupstart"
						),
						
						array(  "label" => esc_html__("Title Font Size", 'dani'),
								"desc" => "",
								"id" => "captionsize",
								"type" => "selectbox",
				   				"sendval" => true,
								"option" => array( 
									array(	"name" => esc_html__("h1", 'dani'), 
											"value" => "h1"),
									array(	"name" => esc_html__("h2", 'dani'), 
											"value" => "h2"),
									array(	"name" => esc_html__("h3", 'dani'), 
											"value" => "h3"),
									array(	"name" => esc_html__("h4", 'dani'), 
											"value" => "h4"),
									array(	"name" => esc_html__("h5", 'dani'), 
											"value" => "h5"),
									array(	"name" => esc_html__("h6", 'dani'), 
											"value" => "h6")
									),
								"default" => "h4"
							),
							
				array( 	"id" => "sr-portfolioitems-hovercaption",
						"hiding" => "onhover onstart belowthumb",	
						"type" => "hidinggroupend"
						),
				  
				array( 	"id" => "sr-portfolioitems-hovercaption",
						"hiding" => "onhover onstart",	
						"type" => "hidinggroupstart"
						),
						
						array(  "label" => esc_html__("Caption Position", 'dani'),
								"desc" => esc_html__("Choose a vertical caption position.", 'dani'),
								"id" => "captionposition",
								"type" => "selectbox",
								"sendval" => true,
								"option" => array( 
									array(	"name" => esc_html__("Top", 'dani'), 
											"value" => "top"),
									array(	"name" => esc_html__("Center", 'dani'), 
											"value" => "center"),
									array(	"name" => esc_html__("Bottom", 'dani'), 
											"value" => "bottom")
									),
								"default" => "bottom"
							),
							  
						array(  "label" => esc_html__("Caption Alignment", 'dani'),
								"desc" => "",
								"id" => "captionalignment",
								"type" => "selectbox",
								"sendval" => true,
								"option" => array( 
									array(	"name" => esc_html__("Left align", 'dani'), 
											"value" => "align-left"),
									array(	"name" => esc_html__("Center align", 'dani'), 
											"value" => "align-center"),
									array(	"name" => esc_html__("Right align", 'dani'), 
											"value" => "align-right")
									),
								"default" => "align-left"
							),
							
				array( 	"id" => "sr-portfolioitems-hovercaption",
						"hiding" => "onhover onstart",	
						"type" => "hidinggroupend"
						),
				  
				array( 	"id" => "sr-portfolioitems-hovercaption",
						"hiding" => "onhover onstart belowthumb",	
						"type" => "hidinggroupstart"
						),
							
						array(  "label" => esc_html__("Display category", 'dani'),
								"desc" => "",
								"id" => "captioncategory",
								"type" => "checkbox-hiding",
								"sendval" => true,
								"option" => array( 
									array(	"name" => esc_html__("Show", 'dani'), 
											"value" => "1"),
									array(	"name" => esc_html__("Hide", 'dani'), 
											"value" => "0")
									),
								"default" => "1"
							),
						
				array( 	"id" => "sr-portfolioitems-hovercaption",
						"hiding" => "onhover onstart belowthumb",	
						"type" => "hidinggroupend"
						),
											
				array( 	"id" => "sr-portfolioitems-hovercaption",
						"hiding" => "onstart",	
						"type" => "hidinggroupstart"
						),
												  
						array(  "label" => esc_html__("Caption text color", 'dani'),
								"desc" => "",
								"id" => "captioncolor",
								"type" => "selectbox",
								"sendval" => true,
								"option" => array( 
									array(	"name" => esc_html__("Light", 'dani'), 
											"value"=> "caption-light"),
									array(	"name" => esc_html__("Dark", 'dani'), 
											"value" => "caption-dark"),
									),
								"default" => "caption-light"
							),
												
				array( 	"id" => "sr-portfolioitems-hovercaption",
						"hiding" => "onstart",
						"type" => "hidinggroupend"
						),
						
				array( "label" => esc_html__("Hover Color", 'dani'),
					   "desc" => "",
					   "id" => "hovercolor",
					   "type" => "selectbox-hiding",
					   "sendval" => true,
					   "option" => array( 
							array(	"name" => esc_html__("Light", 'dani'), 
									"value"=> "overlay-effect"),
							array(	"name" => esc_html__("Dark", 'dani'), 
									"value" => "overlay-effect text-light"),
							array(	"name" => esc_html__("No hover color", 'dani'), 
									"value" => "no-overlay")
							),
							"default" => "overlay-effect"
					  ),
					  
					array( 	"id" => "sr-portfolioitems-hovercolor",
							"hiding" => "overlay-effect",	
							"type" => "hidinggroupstart"
							),
							array(  "label" => esc_html__("Show arrow", 'dani'),
									"desc" => "",
									"id" => "captionarrow",
									"type" => "checkbox",
									"sendval" => true,
									"option" => array( 
										array(	"name" => esc_html__("Yes", 'dani'), 
												"value" => "1"),
										array(	"name" => esc_html__("No", 'dani'), 
												"value" => "0")
										),
									"default" => "1"
								),
													
					array( 	"id" => "sr-portfolioitems-hovercolor",
							"hiding" => "overlay-effect",
							"type" => "hidinggroupend"
							),
								  
		array( "id" => "sr-pb-tab-hovereffect",
			   "type" => "tabend"
			  ),
		
		)
	)
);


if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	
	$shop_pagebuilder = array(
	array(  
		'title' => esc_html__('Shop Grid', 'dani'),
	   	'id'    => 'sr-shopitems',
	   	'desc' => '',
	   	'type' => 'row',
	   	'icon' => 'dashicons-cart',
		'fields' => array(
		
			array( "name" => esc_html__("Grid Options", 'dani'),
				   "id" => "sr-pb-tab-shopgridlayout",
				   "type" => "tabstart"
				  ),
			
				array( "label" => esc_html__("Grid Width", 'dani'),
					   "desc" => "",
					   "id" => "gridwidth",
					   "type" => "selectbox",
					   "sendval" => true,
					   "option" => array( 
							array(	"name" => esc_html__("Default (1200px)", 'dani'), 
									"value"=> "wrapper"),
							array(	"name" => esc_html__("Big (1660px)", 'dani'), 
									"value"=> "wrapper-big"),
							array(	"name" => esc_html__("Fullwidth", 'dani'), 
									"value" => "no-wrapper")
							),
						"default" => "wrapper"
					  ),
					  
				array( "label" => esc_html__("Grid Type", 'dani'),
					   "desc" => "",
					   "id" => "gridtype",
					   "type" => "selectbox-hiding",
					   "sendval" => true,
					   "option" => array( 
							array(	"name" => esc_html__("Default Grid", 'dani'), 
									"value"=> "isotope"),
							array(	"name" => esc_html__("Smart Scroll", 'dani'), 
									"value" => "smartscroll")
							),
						"default" => "isotope"
					  ),
					  
					array( 	"id" => "sr-shopitems-gridtype",
							"hiding" => "isotope",	
							"type" => "hidinggroupstart"
							),
													  
							array( "label" => esc_html__("Columns", 'dani'),
								   "desc" => "",
								   "id" => "gridmasonrycol",
								   "type" => "selectbox",
								   "sendval" => true,
								   "option" => array( 
										array(	"name" => "2", 
												"value"=> "2"),
										array(	"name" => "3", 
												"value" => "3"),
										array(	"name" => "4", 
												"value" => "4"),
										array(	"name" => "5", 
												"value" => "5")
										),
								   "default" => "3"
								  ),
													
					array( 	"id" => "sr-shopitems-gridtype",
							"hiding" => "isotope",	
							"type" => "hidinggroupend"
							),
							
					array( 	"id" => "sr-shopitems-gridtype",
							"hiding" => "smartscroll",	
							"type" => "hidinggroupstart"
							),
							
							array( "label" => esc_html__("Columns", 'dani'),
								   "desc" => "",
								   "id" => "gridsmartcol",
								   "type" => "selectbox",
								   "sendval" => true,
								   "option" => array( 
										array(	"name" => "2", 
												"value"=> "2"),
										array(	"name" => "3", 
												"value" => "3")
										),
								   "default" => "2"
								  ),					
							
					array( 	"id" => "sr-shopitems-gridtype",
							"hiding" => "smartscroll",	
							"type" => "hidinggroupend"
							),
												
					array( "label" => esc_html__("Spacing", 'dani'),
						   "desc" => esc_html__("Do you want the items to be spaced?", 'dani'),
						   "id" => "gridspaced",
						   "type" => "checkbox",
						   "sendval" => true,
						   "option" => array( 
								array(	"name" => esc_html__("Yes", 'dani'), 
										"value"=> "spaced"),		 
								array(	"name" => esc_html__("No", 'dani'), 
										"value" => "not-spaced")
								),
							"default" => "spaced"
						  ),
						  
					array( 	"label" => esc_html__("Count (products per page)", 'dani'),
							"desc" => esc_html__('How many items to show (products per page)? Enter "-1" to show all.', 'dani'),
							"id" => "count",
							"type" => "text",
							"sendval" => true,
							"default" => "4"
						  ),
						  
					array( 	"id" => "sr-shopitems-gridtype",
							"hiding" => "isotope",	
							"type" => "hidinggroupstart"
							),
												
						array( 	"label" => esc_html__("Pagination / Load More", 'dani'),
								"desc" => esc_html__('Do you want to enable any sort of pagination or load more?', 'dani'),
								"id" => "pagination",
								"type" => "selectbox",
								"sendval" => true,
								"option" => array( 
									array(	"name" => esc_html__("No", 'dani'), 
											"value"=> "0"),		 
									array(	"name" => esc_html__("Pagination", 'dani'), 
											"value" => "pagination"),
									array(	"name" => esc_html__("Load More", 'dani'), 
											"value" => "loadonclick"),
									array(	"name" => esc_html__("Infinity Load", 'dani'), 
											"value" => "infiniteload")
									),
									"default" => "0"
							  ),
								
					array( 	"id" => "sr-shopitems-gridtype",
							"hiding" => "isotope",	
							"type" => "hidinggroupend"
							),
							
											  
			array( "id" => "sr-pb-tab-shopgridoptions",
				   "type" => "tabend"
				  ),
				  
			array( "name" => esc_html__("Item Options", 'dani'),
				   "id" => "sr-pb-tab-shopitemlayout",
				   "type" => "tabstart"
				  ),
				  
				  	array( "label" => esc_html__("Layout Option", 'dani'),
						   "desc" => "",
						   "id" => "layoutcustom",
						   "type" => "selectbox-hiding",
						   "sendval" => true,
						   "option" => array( 
								array(	"name" => esc_html__("Inherit from Theme Options", 'dani'),
										"value"=> "inherit"),
								array(	"name" => "Customize for this grid", 
										"value" => "custom")
								),
						   "default" => "inherit"
						  ),	
						  
					array( 	"id" => "sr-shopitems-layoutcustom",
							"hiding" => "custom",	
							"type" => "hidinggroupstart"
							),
							
							array( "label" => esc_html__("Item Layout", 'dani'),
								   "desc" => "",
								   "id" => "itemlayout",
								   "type" => "selectbox-hiding",
								   "sendval" => true,
								   "option" => array( 
										array(	"name" => esc_html__("Infos below image", 'dani'), 
												"value"=> "below"),
										array(	"name" => esc_html__("Infos across Image (bottom)", 'dani'), 
												"value"=> "across-bottom"),
										array(	"name" => esc_html__("Infos across Image (top)", 'dani'), 
												"value"=> "across-top"),
										array(	"name" => esc_html__("Infos across Image (center)", 'dani'), 
												"value"=> "across-center")
										),
								   "default" => "below"
								  ),								
								  
							array( 	"id" => "sr-shopitems-itemlayout",
									"hiding" => "across-bottom across-top across-center",	
									"type" => "hidinggroupstart"
								),
								
								array( "label" => esc_html__("Show Infos", 'dani'),
									   "desc" => esc_html__("Do you want to show the infos (Item title, Price, etc.) on start, or only display them when hovering the image?", 'dani'),
									   "id" => "showinfos",
						   		   	   "sendval" => true,
									   "type" => "selectbox",
									   "option" => array(
											array(	"name" => esc_html__("Always show infos", 'dani'), 
													"value"=> "onstart"),
											array(	"name" => esc_html__("Show infos on hover", 'dani'), 
													"value"=> "onhover")
											),
									   "default" => "onstart"
									  ),
								
							array( 	"id" => "sr-shopitems-layoutcustom",
									"type" => "hidinggroupend"
								),
							
							array( "label" => esc_html__("Hover Color", 'dani'),
								   "desc" => esc_html__("What hover effect do you would like to have when hovering the image?", 'dani'),
								   "id" => "itemhover",
						   		   "sendval" => true,
								   "type" => "selectbox-hiding",
								   "option" => array(
										array(	"name" => esc_html__("Light", 'dani'), 
												"value"=> "text-dark"),
										array(	"name" => esc_html__("Dark", 'dani'), 
												"value"=> "text-light"),
										array(	"name" => esc_html__("Custom", 'dani'), 
												"value"=> "custom"),
										array(	"name" => esc_html__("No hover color", 'dani'), 
												"value"=> "0")
										),
								   "default" => "text-dark"
								  ),
								array( 	"id" => "sr-shopitems-itemhover",
										"hiding" => "custom",	
										"type" => "hidinggroupstart"
									),
									
									array( "label" => "",
										   "desc" => esc_html__("This takes the custom hover color from the theme options", 'dani'),
										   "id" => "itemhovercustom",
										   "type" => "info"
										  ),
									
								array( 	"id" => "sr-shopitems-itemhover",
										"type" => "hidinggroupend"
									),
								  
							array( "label" => esc_html__("Title Font Size", 'dani'),
								   "desc" => "",
								   "id" => "titlesize",
						   		    "sendval" => true,
								   "type" => "selectbox",
								   "option" => array(		 
										array(	"name" => "h1",
												"value" => "h1"),
										array(	"name" => "h2",
												"value" => "h2"),
										array(	"name" => "h3",
												"value" => "h3"),
										array(	"name" => "h4",
												"value" => "h4"),
										array(	"name" => "h5",
												"value" => "h5"),
										array(	"name" => "h6",
												"value" => "h6")
										),
								   "default" => "h5"
								  ),
								  
							array( 	"label" => esc_html__("Show Item Price", 'dani'),
								    "desc" => esc_html__('Want to display the price?', 'dani'),
									"id" => "showprice",
						   		    "sendval" => true,
									"type" => "checkbox"
									),
									
							array( 	"label" => esc_html__("Add to cart", 'dani'),
								    "desc" => esc_html__('Show the "Add to cart" button in the grid items.', 'dani'),
									"id" => "showaddtocart",
									"sendval" => true,
									"type" => "checkbox"
									),
									
							array( 	"label" => esc_html__("Show Sale Badge", 'dani'),
								    "desc" => esc_html__('Enable the sale badge', 'dani'),
									"id" => "showsale",
									"sendval" => true,
									"type" => "checkbox"
									),			
							
					array( 	"id" => "sr-shopitems-layoutcustom",
							"hiding" => "smartscroll",	
							"type" => "hidinggroupend"
							),
				  
			array( "id" => "sr-pb-tab-shopitemlayout",
				   "type" => "tabend"
				  ),
				  
			array( "name" => esc_html__("Filter & Order", 'dani'),
				   "id" => "sr-pb-tab-shopfiltergrid",
				   "type" => "tabstart"
				  ),
				  
					array( "label" => esc_html__("Show Items", 'dani'),
						   "desc" => "",
						   "id" => "filtershow",
						   "type" => "selectbox-hiding",
						   "sendval" => true,
						   "option" => array( 
								array(	"name" => esc_html__("Show All items", 'dani'), 
										"value"=> "all"),
								array(	"name" => esc_html__("Select by category", 'dani'), 
										"value"=> "cat")
								),
							"default" => "all"
						  ),
						  
					array( 	"id" => "sr-shopitems-filtershow",
							"hiding" => "cat",	
							"type" => "hidinggroupstart"
							),
							
							array( "label" => esc_html__("Categories", 'dani'),
								   "desc" => esc_html__("Select the categories you want to display.  Select multiple by holding/pressing 'cmd' or 'ctrl'", 'dani'),
								   "id" => "filtercategory",
								   "type" => "category",
								   "sendval" => true,
								   "option" => "product"
								  ),
							
					array( 	"id" => "sr-shopitems-filtershow",
							"hiding" => "cat",	
							"type" => "hidinggroupend"
							),
							
					array( "label" => esc_html__("Order By", 'dani'),
						   "desc" => "",
						   "id" => "filterorder",
						   "type" => "selectbox",
						   "sendval" => true,
						   "option" => array( 
								array(	"name" => esc_html__("Date", 'dani'), 
										"value"=> "date"),
								array(	"name" => esc_html__("Title", 'dani'), 
										"value"=> "title"),
								array(	"name" => esc_html__("Random", 'dani'), 
										"value"=> "rand")
								),
							"default" => "date"
						  ),
					
					array( "label" => esc_html__("Sort order", 'dani'),
						   "desc" => "",
						   "id" => "filtersort",
						   "type" => "selectbox",
						   "sendval" => true,
						   "option" => array( 
								array(	"name" => esc_html__("Descending", 'dani'), 
										"value"=> "DESC"),
								array(	"name" => esc_html__("Ascending", 'dani'), 
										"value"=> "ASC")
								),
							"default" => "DESC"
						  ),
				  
			array( "id" => "sr-pb-tab-shopfiltergrid",
				   "type" => "tabend"
				  )
		
		)
		
	)
	);
	array_splice($dani_meta_pagebuilder, count($dani_meta_pagebuilder), 0, $shop_pagebuilder);
}

//print_r($dani_meta_pagebuilder);


function dani_show_meta_pagebuilder() {  
	global $dani_meta_pagebuilder, $post; 
	
 	// Use nonce for verification  
 	echo '<input type="hidden" name="meta_pagebuilder_nonce" value="'.wp_create_nonce(basename(__FILE__)).'" />'; 
	dani_write_pagebuilder($dani_meta_pagebuilder);
}




/*-----------------------------------------------------------------------------------*/
/*	WRITE PAGEBUILDER
/*-----------------------------------------------------------------------------------*/
function dani_write_pagebuilder($pagebuildermeta) {
	global $post; 
	
	/* Bugfix for export/import */
	$json = str_replace("\\\\", "\\", get_post_meta($post->ID, '_sr_pagebuilder_json', true));
		
	echo '<div id="sr-pagebuilder" class="sr-style">';
		
	// Main Textareas
	echo '<div class="fieldareas">';
	echo '<textarea name="'.'_sr_pagebuilder" id="'.'_sr_pagebuilder">'.get_post_meta($post->ID, '_sr_pagebuilder', true).'</textarea>';
	echo '<textarea name="'.'_sr_pagebuilder_json" id="'.'_sr_pagebuilder_json">'.$json.'</textarea>';
	
	echo '<textarea name="'.'_sr_pagebuilder_backup_one" id="'.'_sr_pagebuilder_backup_one">'.get_post_meta($post->ID, '_sr_pagebuilder', true).'</textarea>';
	echo '<textarea name="'.'_sr_pagebuilder_json_backup_one" id="'.'_sr_pagebuilder_json_backup_one">'.$json.'</textarea>';
	echo '<textarea name="'.'_sr_pagebuilder_json_backup_one_tmp" id="'.'_sr_pagebuilder_json_backup_one_tmp">'.get_post_meta($post->ID, '_sr_pagebuilder_json_backup_one', true).'</textarea>';
	echo '</div>';
	
	
	// Activate Pagebuilder
	echo '<input type="hidden" name="'.'_sr_pagebuilder_active" class="'.'_sr_pagebuilder_active" id="'.'_sr_pagebuilder_active" value="'.get_post_meta($post->ID, '_sr_pagebuilder_active', true).'">';
	echo '<a href="#" id="sr-disable-pagebuilder">'.esc_html__('Deactivate Pagebuilder', 'dani').'</a>';
	
	
	
	
	// 		********
	//		Pagebuilder VISUAL
	// 		********	
	echo '<div id="sr-pagebuilder-visual" class="sortable-container">';
	
	if (get_post_meta($post->ID, '_sr_pagebuilder_json', true) !== '') {
	$json = json_decode($json);
	if($json) {
	
	// icon array
	$pbIcons = array();
	foreach ($pagebuildermeta as $ic) {
		if (isset($ic['icon'])) { 
			$pbIcons[$ic['id']] = $ic['icon'];
		}
	}
		
	foreach($json->section as $section) {	
	
		$visualName = ''; $i = 0;	
		if (isset($section->options)) { foreach ($section->options as $o) { 
			if ($i == 0 || $o->oName == 'name') { $visualName = '<i>'.$o->oVal.'</i>'; } 
			$i++;
		} }
		
		$visualIcon = '';
		if (isset($pbIcons[$section->shortcode])) { $visualIcon = '<span class="icon dashicons-before '.$pbIcons[$section->shortcode].'"></span>';  }
		
		switch($section->shortcode) {
			
	
			// text
			case 'text':
				$jsonContent = json_encode($section)	;
				$thisContent = false;
				foreach ($section->options as $o) {
					if ($o->oName == 'content') { $thisContent =  $o->oVal;}
				}
				echo '<div class="visualsection '.$section->shortcode.'">
						<div class="action-bar">'.$visualIcon.'<span class="section-name">Text / Editor</span>
						<a href="#" class="delete-section" title="delete"></a>
						<a href="#sr-pagebuilder-popup-'.$section->shortcode.'" class="edit-section"  title="edit"></a>
						<a href="#" class="clone-section"  title="clone"></a>
						</div>
					<textarea class="shortcode shortcode-start">'.$thisContent.'</textarea>
					<textarea class="json json-start">'.$jsonContent.'</textarea>';
					
				echo '<div class="visualcontent"><div class="textcontent">'.$thisContent.'</div>
							<div class="pseudo-action">
								<a href="#" class="delete-pseudo" title="delete"></a>
								<a href="#" class="edit-pseudo"  title="edit"></a>
								<a href="#" class="clone-pseudo"  title="clone"></a>
							</div>
						</div>';
							
				echo '</div>';
			break;
			
			// spacer
			case 'sr-spacer':
				echo '<div class="visualsection light '.$section->shortcode.'">
						<div class="action-bar">'.$visualIcon.'<span class="section-name">Spacer '.$visualName.'</span>
						<a href="#" class="delete-section" title="delete"></a>
						<a href="#sr-pagebuilder-popup-'.$section->shortcode.'" class="edit-section"  title="edit"></a>
						<a href="#" class="clone-section"  title="clone"></a>
						</div>';
				echo '<textarea class="shortcode shortcode-start">['.$section->shortcode.' ';
				foreach ($section->options as $o) {
					echo ' '.$o->oName.'="'.$o->oVal.'"'; 
				}
				echo ']</textarea>';
				$jsonContent = json_encode($section)	;
				echo '<textarea class="json json-start">'.$jsonContent.'</textarea>';
				echo '</div>';
			break;
			
			
			// teammemeber
			case 'sr-teammember':
				$jsonContent = json_encode($section)	;
				$thisContent = false;
				foreach ($section->options as $o) {
					if ($o->oName == 'content') { $thisContent =  $o->oVal;}
				}
				echo '<div class="visualsection '.$section->shortcode.'">
						<div class="action-bar">'.$visualIcon.'<span class="section-name">Team Member '.$visualName.'</span>
						<a href="#" class="delete-section" title="delete"></a>
						<a href="#sr-pagebuilder-popup-'.$section->shortcode.'" class="edit-section"  title="edit"></a>
						<a href="#" class="clone-section"  title="clone"></a>
						</div>';
				$thisContent = false;	
				echo '<textarea class="shortcode shortcode-start">['.$section->shortcode.' ';
				foreach ($section->options as $o) {
					if ($o->oName == 'content') { $thisContent =  $o->oVal; } else {
					echo ' '.$o->oName.'="'.$o->oVal.'"'; }
				}
				echo ']'.$thisContent.'</textarea>';	
				echo '	<textarea class="json json-start">'.$jsonContent.'</textarea>';
			break;
			
			// /teammember (end team member)
			case '/sr-teammember':
				echo '<textarea class="shortcode">['.$section->shortcode.']</textarea><textarea class="json">{"shortcode":"'.$section->shortcode.'"}</textarea></div>';
			break;
			
			
			// googlemap
			case 'sr-googlemap':
				$jsonContent = json_encode($section)	;
				$thisContent = false;
				foreach ($section->options as $o) {
					if ($o->oName == 'content') { $thisContent =  $o->oVal;}
				}
				
				echo '<div class="visualsection '.$section->shortcode.'">
						<div class="action-bar">'.$visualIcon.'<span class="section-name">Google Map</span>
						<a href="#" class="delete-section" title="delete"></a>
						<a href="#sr-pagebuilder-popup-'.$section->shortcode.'" class="edit-section"  title="edit"></a>
						<a href="#" class="clone-section"  title="clone"></a>
						</div>';	
				$thisContent = false;	
				echo '<textarea class="shortcode shortcode-start">['.$section->shortcode.' ';
				foreach ($section->options as $o) {
					if ($o->oName == 'content') { $thisContent =  $o->oVal; } else {
					echo ' '.$o->oName.'="'.$o->oVal.'"'; }
				}
				echo ']'.$thisContent.'</textarea>';	
				echo '	<textarea class="json json-start">'.$jsonContent.'</textarea>';
			break;
			
			// /googlemap (end googlemap)
			case '/sr-googlemap':
				echo '<textarea class="shortcode">['.$section->shortcode.']</textarea><textarea class="json">{"shortcode":"'.$section->shortcode.'"}</textarea>
				</div>';
			break;
			
			// columns
			case 'col':
				$size = '';
				$shortcode = $section->shortcode;
				foreach ($section->options as $o) {
					if ($o->oName == 'size') { $size = $o->oVal;}
					$shortcode .= ' '.$o->oName.'="'.$o->oVal.'"'; 
				}
				$jsonContent = json_encode($section)	;
				
				echo '<div class="col '.$size.' visualsection">
								<textarea class="shortcode shortcode-start">['.$shortcode.']</textarea>
								<textarea class="json json-start">'.$jsonContent.'</textarea>';
				//echo '<div class="action-bar"><a href="#sr-pagebuilder-popup-'.$section->shortcode.'" class="edit-section"></a></div>';				
				echo '<div class="element-container col-inner">';
			break;
			
			// /columns (end columns)
			case '/col':
				echo '<a class="sr-add-element sr-open-popup disable-sortable" href="#sr-pagebuilder-popup-element">Insert Element</a></div>
				<textarea class="shortcode">['.$section->shortcode.']</textarea><textarea class="json">{"shortcode":"'.$section->shortcode.'"}</textarea>
				</div>';
			break;
			
			// columnsection
			case 'columnsection':
				$wrapperVal = '';
				foreach ($section->options as $o) { if ($o->oName == 'wrapper') { $wrapperVal = $o->oVal; } }
				echo '<div class="visualsection '.$wrapperVal.' '.$section->shortcode.' sr-clearfix">';
				
				echo '<textarea class="shortcode shortcode-start">[columnsection ';
				foreach ($section->options as $o) {
					echo ' '.$o->oName.'="'.$o->oVal.'"'; 
				}
				echo ']</textarea>';
				
				$jsonContent = json_encode($section)	;
				echo '<textarea class="json json-start">'.$jsonContent.'</textarea>';
				echo '	<div class="action-bar">'.$visualIcon.'<span class="section-name">Column Row</span>
						<a href="#" class="delete-section" title="delete"></a>
						<a href="#sr-pagebuilder-popup-'.$section->shortcode.'" class="edit-section"  title="edit"></a>
						<a href="#" class="clone-section"  title="clone"></a>
						</div>
						<div class="columns sr-clearfix column-inner">';
			break;
			
			
			// /columnsection
			case '/columnsection':
				echo '</div>	<textarea class="shortcode">['.$section->shortcode.']</textarea><textarea class="json">{"shortcode":"'.$section->shortcode.'"}</textarea>
					</div>';
			break;
						
			
			// fullwidthsection
			case 'fullwidthsection':
				echo '<div class="visualsection '.$section->shortcode.' sr-clearfix ui-sortable-helper">';
				
				$wrapperVal = '';
				echo '<textarea class="shortcode shortcode-start">[fullwidthsection ';
				foreach ($section->options as $o) {
					echo ' '.$o->oName.'="'.$o->oVal.'"'; 
					if ($o->oName == 'wrapper') { $wrapperVal = $o->oVal; }
				}
				echo ']</textarea>';
				
				$jsonContent = json_encode($section)	;
				echo '<textarea class="json json-start">'.$jsonContent.'</textarea>';
				echo '	<div class="action-bar">'.$visualIcon.'<span class="section-name">Background Section '.$visualName.'</span>
						<a href="#" class="delete-section" title="delete"></a>
						<a href="#sr-pagebuilder-popup-'.$section->shortcode.'" class="edit-section"  title="edit"></a>
						<a href="#" class="clone-section"  title="clone"></a>
						</div>';
				echo '<div class="fullwidth-inner sr-clearfix visual-inner">';
			break;
			
			// /fullwidthsection
			case '/fullwidthsection':
				echo '<div class="pb-message disable-sortable">
					<a class="sr-add-first-row sr-button sr-open-popup" data-disable="fullwidthsection" href="#sr-pagebuilder-popup-row">Add Row</a></div></div>';
				echo '<textarea class="shortcode">['.$section->shortcode.']</textarea>
				<textarea class="json">{"shortcode":"'.$section->shortcode.'"}</textarea>
					</div>';
			break;
			
			
			// sr-gallery
			case 'sr-gallery':
				$jsonContent = json_encode($section)	;
				$jsonContent = str_replace("\/","/",$jsonContent);		// Workaround for "\/" in json
				
				echo '<div class="visualsection '.$section->shortcode.'">
						<div class="action-bar">'.$visualIcon.'<span class="section-name">Gallery</span>
						<a href="#" class="delete-section" title="delete"></a>
						<a href="#sr-pagebuilder-popup-'.$section->shortcode.'" class="edit-section"  title="edit"></a>
						<a href="#" class="clone-section"  title="clone"></a>
						</div>';		
				echo '<textarea class="shortcode shortcode-start">[sr-gallery ';
				foreach ($section->options as $o) {
					if ($o->oName === 'medias') { 
						$images = json_decode($o->oVal);
						$items = '';
						foreach($images->sortable as $j) {
							$items .= $j->id.',';
						}
						echo $o->oName.'="'.trim($items, ",").'"'; 
					} else {
					echo ' '.$o->oName.'="'.$o->oVal.'"'; 
					}
				}
				echo ']</textarea>';
				echo '<textarea class="json json-start">'.$jsonContent.'</textarea>';
				echo '</div>';
			break;
			
			
			// sr-blogposts
			case 'sr-blogposts':
				echo '<div class="visualsection '.$section->shortcode.'">
						<div class="action-bar">'.$visualIcon.'<span class="section-name">Blog Posts</span>
						<a href="#" class="delete-section" title="delete"></a>
						<a href="#sr-pagebuilder-popup-'.$section->shortcode.'" class="edit-section"  title="edit"></a>
						<a href="#" class="clone-section"  title="clone"></a>
						</div>';
				echo '<textarea class="shortcode shortcode-start">['.$section->shortcode.' ';
				foreach ($section->options as $o) {
					echo ' '.$o->oName.'="'.$o->oVal.'"'; 
				}
				echo ']</textarea>';
				$jsonContent = json_encode($section)	;
				echo '<textarea class="json json-start">'.$jsonContent.'</textarea>';
				echo '</div>';
			break;
			
			
			// sr-portfolioitems
			case 'sr-portfolioitems':
				echo '<div class="visualsection '.$section->shortcode.'">
						<div class="action-bar">'.$visualIcon.'<span class="section-name">Portfolio Grid</span>
						<a href="#" class="delete-section" title="delete"></a>
						<a href="#sr-pagebuilder-popup-'.$section->shortcode.'" class="edit-section"  title="edit"></a>
						<a href="#" class="clone-section"  title="clone"></a>
						</div>';
				echo '<textarea class="shortcode shortcode-start">['.$section->shortcode.' ';
				foreach ($section->options as $o) {
					echo ' '.$o->oName.'="'.$o->oVal.'"'; 
				}
				echo ']</textarea>';
				$jsonContent = json_encode($section)	;
				echo '<textarea class="json json-start">'.$jsonContent.'</textarea>';
				echo '</div>';
			break;
			
			// sr-shopitems
			case 'sr-shopitems':
				echo '<div class="visualsection '.$section->shortcode.'">
						<div class="action-bar">'.$visualIcon.'<span class="section-name">Shop Grid</span>
						<a href="#" class="delete-section" title="delete"></a>
						<a href="#sr-pagebuilder-popup-'.$section->shortcode.'" class="edit-section"  title="edit"></a>
						<a href="#" class="clone-section"  title="clone"></a>
						</div>';
				echo '<textarea class="shortcode shortcode-start">['.$section->shortcode.' ';
				foreach ($section->options as $o) {
					echo ' '.$o->oName.'="'.$o->oVal.'"'; 
				}
				echo ']</textarea>';
				$jsonContent = json_encode($section)	;
				echo '<textarea class="json json-start">'.$jsonContent.'</textarea>';
				echo '</div>';
			break;
			
			
		} // END switch
		} // END foreach section
		
		echo '<div class="pb-message sr-pb-last disable-sortable"><div class="pb-empty message">Your Pagebuilder is empty<br>Start adding Rows and Elements to your content</div><a class="sr-add-first-row sr-button sr-open-popup" href="#sr-pagebuilder-popup-row">Add Row</a></div>';
	} else {
		// If json has error
		$jsonBackup = str_replace("\\\\", "\\", get_post_meta($post->ID, '_sr_pagebuilder_json_backup_one', true));	
		$jsonBackup = json_decode($jsonBackup);
		if (get_post_meta($post->ID, '_sr_pagebuilder_json_backup_one', true) && get_post_meta($post->ID, '_sr_pagebuilder_json_backup_one', true) !== '' && $jsonBackup) {
		
		echo '<div class="pb-message disable-sortable"><div class="pb-error message">Unfortunately something went wrong.<br>It\'s recommended to restore the pagebuilder, so you do not to loose your previous savings.</div>
		<input type="hidden" name="sr-pagebuilder-restore" id="sr-pagebuilder-restore" value="false">
		<a href="#" class="sr-button" id="restore-pagebuilder">Restore Now</a>
		</div>';	
		} else {
			echo '<div class="pb-message sr-pb-last disable-sortable"><div class="pb-error message">Unfortunately something went wrong.<br>It\'s not possible to restore your previous savings and you need to recreate the different elements.<br><small>Some of your elements have errors and can\'t be shown here, although it might display fine on your frontend.</small></div><a class="sr-add-first-row sr-button sr-open-popup" href="#sr-pagebuilder-popup-row">Add Row</a></div>';	
		}
	}
	
	} else { 
		// Pagebuilder is empty
		echo '<div class="pb-message sr-pb-last disable-sortable"><div class="pb-empty message">Your Pagebuilder is empty<br>Start adding Rows and Elements to your content</div><a class="sr-add-first-row sr-button sr-open-popup" href="#sr-pagebuilder-popup-row">Add Row</a></div>';
	}
		
	echo '</div>'; // END #sr-pagebuilder-visual
	// 		********
	
	//		Pagebuilder VISUAL
	
	// 		********	

			
			
	
	
	// 		********
	
	//		Pagebuilder POPUP ($dani_meta_pagebuilder)
	
	// 		********
	echo '<div id="sr-pagebuilder-popup-bg"></div>';
	
	
	/* Popup Add Row */
	echo '<div id="sr-pagebuilder-popup-row" class="sr-pagebuilder-popup">';
	echo '<div class="popup-title">Add Row <a class="close-popup" href="#">close</a></div>';
	echo '<div class="popup-inner">';
	foreach ($pagebuildermeta as $row) {
		if (strpos($row['type'],'row') !== false) { 
			echo '<a href="#sr-pagebuilder-popup-'.$row['id'].'" class="popup-add-row sr-open-popup '.$row['id'].'">';
			if (isset($row['icon'])) { echo '<span class="icon dashicons-before '.$row['icon'].'"></span>'; }
			echo $row['title'].'</a>';
		}
	}
	echo '</div>';
	echo '</div>';
	/* Popup Add Row */
	
	
	
	/* Popup Add Element */
	echo '<div id="sr-pagebuilder-popup-element" class="sr-pagebuilder-popup">';
	echo '<div class="popup-title">Insert Element <a class="close-popup" href="#">close</a></div>';
	echo '<div class="popup-inner">';
	foreach ($pagebuildermeta as $row) {
		if (strpos($row['type'],'element') !== false) {
			echo '<a href="#sr-pagebuilder-popup-'.$row['id'].'" class="popup-add-element sr-open-popup">';
			if (isset($row['icon'])) { echo '<span class="icon dashicons-before '.$row['icon'].'"></span>'; }
			echo $row['title'].'</a>';
			//echo '<a href="#sr-pagebuilder-popup-'.$row['id'].'" class="popup-add-element sr-open-popup">'.$row['title'].'</a>';
		}
	}
	echo '</div>';
	echo '</div>';
	/* Popup Add Element */
	
	
	
	/* Popup Rows & Elements */
	foreach ($pagebuildermeta as $meta) {
		
		echo '<div id="sr-pagebuilder-popup-'.$meta['id'].'" class="sr-pagebuilder-popup sr-pagebuilder-popup-option" data-name="'.$meta['id'].'">';
		echo '<div class="popup-title">';
		if (isset($meta['icon'])) { echo '<span class="icon dashicons-before '.$meta['icon'].'"></span>'; }
		echo $meta['title'].' <a class="close-popup" href="#">close</a></div>';
		
		// Loop tabs
		$tabCounter = 0;
		foreach ($meta['fields'] as $tab) {
			if ($tab['type'] == 'tabstart') {
				if ($tabCounter == 0) { echo '<ul class="sr-tab-list clearfix">'; $active = "active"; } else { $active = ""; }
				echo '<li class="'.$active.'"><a href="'.$tab['id'].'">'.$tab['name'].'</a></li>';
				$tabCounter++;	
			}
		}
		if ($tabCounter !== 0) { echo '</ul>'; }	
		
		
		echo '<div class="popup-inner sr-post-meta"><div>';
		// empty div needed for clearfix issue
		
				
		// create fields
		$tabCounter = 0;
		foreach ($meta['fields'] as $option) {
			
			$value = '';  
			if (isset($option['default']) && $option['default'] !== '') { $value = $option['default']; }
			
			$sendVal = ''; $formDisable = ''; 
			if (isset($option['sendval']) && $option['sendval']) { $sendVal = ' send-val'; } else { $formDisable = 'disable-on-edit'; }
			
			switch($option['type']) {
				
				// tabstart
				case 'tabstart':
					if ($tabCounter == 0) { $active = "active"; } else { $active = ""; }
					echo '<div class="sr-tab-content '.$active.'" data-tab="'.$option['id'].'">';
					$tabCounter++;	
				break;
				
				// tabend
				case 'tabend':
					echo '</div>';
				break;
				
				
				
				// hidinggroupstart
				case "hidinggroupstart":
					$relatedArray = explode(' ',$option['hiding']);
					$hideClass = '';
					foreach ($relatedArray as $r) { $hideClass .= $option['id'].'_'.$r.' '; }
					echo '<div class="hidinggroup hide'.$option['id'].' '.$hideClass.'">';
				break;
				
				// hidinggroupend
				case "hidinggroupend":
					echo '	</div>';
				break;
				
				// info
				case 'info':
					echo '<div class="option clear">';
						echo '<div class="option-inner">';
							if (isset($option['label']) && $option['label'] !== '') {
								echo '	<div class="option_name">
											<label>'.$option['label'].'</label>
										</div>';
								echo '	<div class="option_value">';
							}
							echo '	<div class="sr-message-info"><i>'.$option['desc'].'</i></div>';	
							if (isset($option['label']) && $option['label'] !== '') {
								echo '	</div>';	
							}
						echo '</div>';
					echo '</div>';
				break;
				
				// hidden
				case 'hidden':
					echo '<input type="hidden" name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" value="'.$value.'"  class="builder'.$option['id'].' theval '.$sendVal.'" data-default="'.$value.'"/>';
				break;
				
				// text
				case 'text':
					echo '<div class="option '.$formDisable.' clear">';
						echo '<div class="option-inner">';
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
									
							echo '	<div class="option_value">
										<input type="text" name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" value="'.$value.'" size="30" class="builder'.$option['id'].' theval '.$sendVal.'" data-default="'.$value.'"/>
									</div>';	
						echo '</div>';
					echo '</div>';
				break;
				
				// editor
				case 'editor':
					echo '<div class="option '.$formDisable.' clear">';
						if ($option['label'] !== '') { 
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
							}
						echo '<div class="option-inner">';
							wp_editor( '', $meta['id'].'-'.$option['id'],array('textarea_rows' => 13,'editor_class' => $sendVal));
						echo '</div>';
						echo '<div class="option_desc"><i>'.$option['desc'].'</i></div>'	;		
					echo '</div>';
				break;
				
				//color
				case "color":
					echo '<div class="option '.$formDisable.' clear">';
						echo '<div class="option-inner">';
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
							echo '	<div class="option_value">
										<input type="text" name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" value="'.$value.'" class="sr-color-field builder'.$option['id'].' theval '.$sendVal.'" data-default="'.$value.'"/>
									</div>';	
						echo '</div>';
					echo '</div>';
				break;
				
				//checkbox
				case 'checkbox':  
					echo '<div class="option '.$formDisable.' clear">';
						echo '<div class="option-inner">';
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
							
							// default options
							$options = array(array(	"name" => esc_html__("On", 'dani'), 
													"value" => "1"),
											 array(	"name" => esc_html__("Off", 'dani'), 
													"value"=> "0"));
							if (isset($option['option']) && $option['option']) { $options = $option['option']; }		
							$i = 0;
							$pseudo = '';
							$select = '';
							foreach ($options as $var) {
								if ($value == $var['value'] || ($value == '' && $i == 0)) { $selected = 'selected="selected"'; $active ='active'; } else { $selected = ''; $active ='';  } 
								$pseudo .= '<a href="#" data-value="'.$var['value'].'" class="'.$active.'"> '.$var['name'].'</a>';
								$select .= '<option value="'.$var['value'].'" '.$selected.'> '.$var['name'].'</option>';
							$i++;	
							}
									
							echo '	<div class="option_value">
										<div class="checkbox-pseudo clearfix">'.$pseudo.'</div>
										<select name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" style="display: none;" class="builder'.$option['id'].' theval '.$sendVal.'" data-default="'.$value.'">'.$select.'</select>
									</div>';		
						echo '</div>';
					echo '</div>';
				break;
				
				
				//checkbox-hiding
				case 'checkbox-hiding':  
					echo '<div class="option '.$formDisable.' clear hiding'.$option['id'].' hiding">';
						echo '<div class="option-inner">';
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
							
							// default options
							$options = array(array(	"name" => esc_html__("On", 'dani'), "value" => "1"),
											 array(	"name" => esc_html__("Off", 'dani'), "value"=> "0"));
							if (isset($option['option']) && $option['option']) { $options = $option['option']; }		
							$i = 0;
							$pseudo = '';
							$select = '';
							foreach ($options as $var) {
								if ($value == $var['value'] || ($value == '' && $i == 0)) { $selected = 'selected="selected"'; $active ='active'; } else { $selected = ''; $active ='';  } 
								$pseudo .= '<a href="#" data-value="'.$var['value'].'" class="'.$active.'"> '.$var['name'].'</a>';
								$select .= '<option value="'.$var['value'].'" '.$selected.'> '.$var['name'].'</option>';
							$i++;	
							}
									
							echo '	<div class="option_value">
										<div class="checkbox-pseudo clearfix">'.$pseudo.'</div>
										<select name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" style="display: none;" class="builder'.$option['id'].' theval '.$sendVal.'" data-default="'.$value.'">'.$select.'</select>
									</div>';		
						echo '</div>';
					echo '</div>';
				break;
				
				// selectbox  
				case 'selectbox':  
					echo '<div class="option '.$formDisable.' clear">';
						echo '<div class="option-inner">';
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
							echo '	<div class="option_value">';
															
							echo '<select name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" class="builder'.$option['id'].' theval '.$sendVal.'" data-default="'.$value.'">';
							$i = 0;
							foreach ($option['option'] as $var) {
								if ($value == $var['value']) { $selected = 'selected="selected"'; } else { if ($value == '' && $i == 0) { $selected = 'selected="selected"'; } else { $selected = '';  } }
								echo '<option value="'.$var['value'].'" '.$selected.'> '.$var['name'].'</option>';
							$i++;	
							}			  
							echo '</select>';
							
						echo '	</div>';	
						
						echo '</div>';
					echo '</div>';
				break;
				
				
				// selectbox-hiding  
				case 'selectbox-hiding':  
					echo '<div class="option '.$formDisable.' clear hiding'.$option['id'].' hiding">';
						echo '<div class="option-inner">';
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
							echo '	<div class="option_value">';
							
							echo '<select name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" class="builder'.$option['id'].' theval '.$sendVal.'" data-default="'.$value.'">';
							$i = 0;
							foreach ($option['option'] as $var) {
								if ($value == $var['value']) { $selected = 'selected="selected"'; } else { if ($value == '' && $i == 0) { $selected = 'selected="selected"'; } else { $selected = '';  } }
								echo '<option value="'.$var['value'].'" '.$selected.'> '.$var['name'].'</option>';
							$i++;	
							}			  
							echo '</select>'; 
						echo '	</div>';		
					
						echo '</div>';
					echo '</div>';
				break;
				
				// image  
				case 'image':  
					echo '<div class="option '.$formDisable.' clear">';
						echo '<div class="option-inner">';
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
							echo '	<div class="option_value">
										<input class="upload_image builder'.$option['id'].' theval '.$sendVal.'" type="hidden" name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" value="'.$value.'" size="30" data-default="'.$value.'"/>
										<input class="sr_upload_image_button sr-button" type="button" value="Upload Image" />
										<input class="sr_remove_image_button sr-button button-remove hide" type="button" value="Remove Image" /><br />
										<span class="preview_image"><img class="'.$option['id'].'"  src="" alt="" /></span>
									</div>';		
						echo '</div>';
					echo '</div>';		
				break;
				
				// video  
				case 'video': 
					echo '<div class="option '.$formDisable.' clear">';
						echo '<div class="option-inner">';
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
							echo '	<div class="option_value">
										<input class="upload_video builder'.$option['id'].' theval '.$sendVal.'" type="text" name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" value="'.$value.'" size="30" data-default="'.$value.'"/>
										<input class="upload_video_button sr-button" type="button" value="Add Video" />
									</div>';		
						echo '</div>';
					echo '</div>'; 
				break;
				
				// custom-select
				case 'custom-select':
					echo '<div class="option '.$formDisable.' clear">';
						echo '<div class="option-inner">';
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
							echo '	<div class="option_value custom-select">
							
										<select name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" style="display: none;" class="builder'.$option['id'].' theval '.$sendVal.'" data-default="'.$value.'">';
										foreach ($option['option'] as $var) {
											echo '<option value="'.$var['value'].'"> '.$var['name'].'</option>';
										}			  
										echo '</select>';
										
										echo '<ul class="sr-clearfix">';
										foreach ($option['option'] as $var) {
											echo '<li data-rel="'.$var['value'].'"><img src="'.esc_url(plugins_url( '/img/'.$var['img'], __FILE__ )).'" /></li>';
										}
										echo '</ul>';
										
							echo '</div>';		
						echo '</div>';
					echo '</div>'; 
				break;
				
				
				// medias  
				case 'medias':
					echo '<div class="option '.$formDisable.' clear">';
						echo '<div class="option-inner">';
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
							echo '	<div class="option_value">';
								
								echo '<div id="sortable'.$option['id'].'" class="sortable-list">';
								echo '<textarea name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" class="builder'.$option['id'].' theval '.$sendVal.' sortable-value pb-medias" style="display:none;">'.$value.'</textarea>';
								echo '<ul id="sortable-'.$option['id'].'" class="sortable-container sortable-media clear">';
								echo '</ul>';
								echo '<a class="add-to-sortable-media add-sortable-button sr-button" data-type="image">Add Image</a>';		
								echo '</div>';
								
							echo '</div>';
						echo '</div>';
					echo '</div>';
				break;
				
				
				// category
				case 'category':
					echo '<div class="option '.$formDisable.' clear">';
						echo '<div class="option-inner">';
							echo '	<div class="option_name">
										<label for="'.$option['id'].'">'.$option['label'].'</label>
										<div class="option_desc"><i>'.$option['desc'].'</i></div>
									</div>';
									
							echo '	<div class="option_value">';
								echo '<select name="builder-'.$meta['id'].''.$option['id'].'" id="'.$meta['id'].'-'.$option['id'].'" class="builder'.$option['id'].' theval '.$sendVal.' pb-multiple" data-default="'.$value.'" size="5" multiple>';
								
								if ($option['option'] == 'portfolio') { $term = 'portfolio_category'; } 
								else if ($option['option'] == 'product') { $term = 'product_cat'; }
								else { $term = 'category'; }
								$categories = get_terms($term);
								foreach ($categories as $cat) {
									echo '<option value="'.$cat->term_id.'">'.$cat->name.'</option>';
								}
								echo '</select>';   
							echo '	</div>';	
						echo '</div>';
					echo '</div>';
				break;
									
			} // END switch
		} // END foreach create fields
			
		echo '
			<div class="pagebuilder-insert">
				<a href="'.$meta['id'].'" id="insertbuilder_'.$meta['id'].'" class="sr-builder-insert sr-button">'.esc_html__("Add Element", 'dani').'</a>
				<a href="'.$meta['id'].'" id="editbuilder_'.$meta['id'].'" class="sr-builder-edit sr-button">'.esc_html__("Edit Element", 'dani').'</a>
			</div>'; // END op-content
			
		echo '</div></div>';		
		echo '</div>';
	
	} // END foreach ($pagebuildermeta as $meta) {
	
	// 		********
	
	//		Pagebuilder POPUP ($dani_meta_pagebuilder)
	
	// 		********	
	
		
			
	echo '<div class="note-bottom"><i><strong>Note</strong>: Revisions does not work for the pagebuilder</i></div>';
	echo '</div>'; // END #sr-pagebuilder
	
	
	
	
	
	
	
	
}




/*-----------------------------------------------------------------------------------*/
/*	Save Datas
/*-----------------------------------------------------------------------------------*/
add_action( 'save_post', 'dani_pagebuilder_save_postdata' );
function dani_pagebuilder_save_postdata( $post_id ) {
	
	// verify nonce  
    if (!isset($_POST['meta_pagebuilder_nonce']) || !wp_verify_nonce($_POST['meta_pagebuilder_nonce'], basename(__FILE__))) 
        return $post_id; 
	
    // check autosave  
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)  
        return $post_id;
	
  	// check permissions  
    if ('page' == $_POST['post_type']) {  
        if (!current_user_can('edit_page', $post_id))  
            return $post_id;  
        } elseif (!current_user_can('edit_post', $post_id)) {  
            return $post_id;  
    } 
	
	
	// check if restore
	if (isset($_POST['sr-pagebuilder-restore']) && $_POST['sr-pagebuilder-restore'] == 'true') {
		
		// restore the main fields
		update_post_meta($post_id, '_sr_pagebuilder', get_post_meta($post_id, '_sr_pagebuilder_backup_one', true));
		update_post_meta($post_id, '_sr_pagebuilder_json',$_POST['_sr_pagebuilder_json_backup_one_tmp']);
		update_post_meta($post_id, '_sr_pagebuilder_active', 'yes');
		
	} else {
	
		$saveFields = array('_sr_pagebuilder','_sr_pagebuilder_json','_sr_pagebuilder_backup_one','_sr_pagebuilder_json_backup_one','_sr_pagebuilder_active');
		// loop through fields and save the data  
		foreach ($saveFields as $field) {  
			$old = get_post_meta($post_id, $field, true);  
			$new = $_POST[$field];
			
			/* Bugfix for export/import */
			if ($field == '_sr_pagebuilder_json') {
				//echo $field.' = '.$new; 
				$new = str_replace("\\\\", "\\\\\\", $_POST[$field]);	
				//echo '<br><br><br>'.$new; 
			} 
			
			if ('' == $new && $old) {  
				delete_post_meta($post_id, $field);  
			} else if ($new !== $old) {  
				update_post_meta($post_id, $field, $new);  
			}  
		} // end foreach 
	
	}

}


/*-----------------------------------------------------------------------------------*/
/*	Register and load function javascript
/*-----------------------------------------------------------------------------------*/
if( !function_exists( 'dani_pagebuilder_scripts' ) ) {
    function dani_pagebuilder_scripts($hook) {
		global $dani_core_version; 
		
		if (get_post_type() !== 'post') {
				
		wp_register_script('pagebuilder-script', plugins_url( '/js/pagebuilder.js', __FILE__ ), '', $dani_core_version,true);
		wp_enqueue_script('pagebuilder-script');
		
		wp_register_style('pagebuilder-style', plugins_url( '/css/pagebuilder.css', __FILE__ ), '', $dani_core_version);
		wp_enqueue_style('pagebuilder-style');
		
		}
    }
    add_action('admin_enqueue_scripts','dani_pagebuilder_scripts',10,1);
}



?>