<?php

/*-----------------------------------------------------------------------------------
	
	Plugin Name: Social Links Widget  
	Description: Show you social links  
	Version: 1.0  
	Author: SpabRice  
	Author URI: http://www.spab-rice.com  
	
-----------------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------------*/
/*	Register Social link Widget & enqueu scripts
/*-----------------------------------------------------------------------------------*/

add_action( 'widgets_init', 'sr_sociallinks_widget' );

function sr_sociallinks_widget() {
	register_widget( 'sr_sociallinks_widget' );
}


/*-----------------------------------------------------------------------------------*/
/*	Widget Class
/*-----------------------------------------------------------------------------------*/

class sr_sociallinks_widget extends WP_Widget {
	
	
	/*  Widget setup  */
	
	function __construct() {
	
		// Widget settings
		$widget_ops = array( 'classname' => 'sr_sociallinks_widget', 'description' => esc_html__('A widget that displays all Social links which have been activated.', 'dani') );
		$control_ops = array( 'width' => 200, 'height' => 350, 'id_base', 'sr-sociallinks-widget' );
		
		// Create widget
		parent::__construct( 'sr_sociallinks_widget', esc_html__('SR - Social Links','dani'), $widget_ops, $control_ops );
	}
	


	/*  Display Widget */
	
	function widget( $args, $instance ) {
		extract( $args );
		
		// Get the inputs
		$sr_title = apply_filters('widget_title', $instance['title'] );
		
		
		
		// Display the WidgetBefore settings
		echo $before_widget;
		
		// Display the title
		if ( $sr_title ) { echo $before_title . $sr_title . $after_title; }
		
			
		/* Display Social Buttons */
		?>
			<ul class="socialmedia-widget" >
            	<?php 
				$socials = array('facebook','twitter','googleplus','vimeo','instagram','dribbble','youtube','deviantart','behance','flickr','linkedin','rss','pinterest','xing','dropbox','stumbleupon','delicious','soundcloud','spotify','codepen','github','lastfm','jsfiddle','mixcloud','tumblr','skype','vk','mail','url');
				foreach($socials as $s) {
				if ($instance[$s] && $instance[$s] !== ''){echo '<li class="'.$s.'"><a href="'.esc_url($instance[$s]).'" target="_blank"></a></li>';}
				}
				?>
             </ul>
         <?php   
		
		
		// Display the WidgetAfter settings
		echo $after_widget;
	}
	
	

	/* Update Widget */
	
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] = strip_tags( $new_instance['title'] );
		
		$socials = array('facebook','twitter','googleplus','vimeo','instagram','dribbble','youtube','deviantart','behance','flickr','linkedin','rss','pinterest','xing','dropbox','stumbleupon','delicious','soundcloud','spotify','codepen','github','lastfm','jsfiddle','mixcloud','tumblr','skype','vk','mail','url');
		foreach($socials as $s) {
			$instance[$s] = strip_tags( $new_instance[$s] );
		}

		return $instance;
	}
	
	
	/* Widget settings */
	
	function form( $instance ) {
		
		// Set up default settings
		$defaults = array(
			'title' => '',
			'facebook' => '',
			'twitter' => '',
			'googleplus' => '',
			'vimeo' => '',
			'instagram' => '',
			'dribbble' => '',
			'youtube' => '',
			'deviantart' => '',
			'behance' => '',
			'flickr' => '',
			'linkedin' => '',
			'rss' => '',
			'pinterest' => '',
			'xing' => '',
			'dropbox' => '',
			'stumbleupon' => '',
			'delicious' => '',
			'soundcloud' => '',
			'spotify' => '',
			'codepen' => '',
			'github' => '',
			'lastfm' => '',
			'jsfiddle' => '',
			'mixcloud' => '',
			'tumblr' => '',
			'skype' => '',
			'vk' => '',
			'mail' => '',
			'url' => ''
		);
		
		

		$instance = wp_parse_args( (array) $instance, $defaults ); 
		
		
		
		?>

		<p>
            <i><?php esc_html_e('Enter your social profile links including "http://"', 'dani'); ?></i>
		</p>
        
        <!-- Title -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e('Widget Title:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" value="<?php echo esc_html($instance['title']); ?>" />
        </p>
        
        
        <!-- Facebook -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'facebook' )); ?>"><?php esc_html_e('Facebook:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'facebook' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'facebook' )); ?>" value="<?php echo esc_html($instance['facebook']); ?>" />
        </p>
        
        
        <!-- Twitter -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'twitter' )); ?>"><?php esc_html_e('Twitter:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'twitter' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'twitter' )); ?>" value="<?php echo esc_html($instance['twitter']); ?>" />
        </p>
        
        
        <!-- Googleplus -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'googleplus' )); ?>"><?php esc_html_e('Google Plus:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'googleplus' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'googleplus' )); ?>" value="<?php echo esc_html($instance['googleplus']); ?>" />
        </p>
        
        
         <!-- vimeo -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'vimeo' )); ?>"><?php esc_html_e('Vimeo:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'vimeo' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'vimeo' )); ?>" value="<?php echo esc_html($instance['vimeo']); ?>" />
        </p>
        
         
        <!-- instagram -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'instagram' )); ?>"><?php esc_html_e('Instagram:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'instagram' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'instagram' )); ?>" value="<?php echo esc_html($instance['instagram']); ?>" />
        </p>
        
        
        <!-- dribbble -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'dribbble' )); ?>"><?php esc_html_e('Dribbble:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'dribbble' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'dribbble' )); ?>" value="<?php echo esc_html($instance['dribbble']); ?>" />
        </p>
        
        
        <!-- youtube -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'youtube' )); ?>"><?php esc_html_e('Youtube:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'youtube' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'youtube' )); ?>" value="<?php echo esc_html($instance['youtube']); ?>" />
        </p>
        
       
        <!-- deviantart -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'deviantart' )); ?>"><?php esc_html_e('Deviantart:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'deviantart' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'deviantart' )); ?>" value="<?php echo esc_html($instance['deviantart']); ?>" />
        </p>
        
        
        <!-- behance -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'behance' )); ?>"><?php esc_html_e('Behance:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'behance' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'behance' )); ?>" value="<?php echo esc_html($instance['behance']); ?>" />
        </p>
        
          
        <!-- flickr -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'flickr' )); ?>"><?php esc_html_e('Flickr:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'flickr' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'flickr' )); ?>" value="<?php echo esc_html($instance['flickr']); ?>" />
        </p>
        
        
         <!-- linkedin -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'linkedin' )); ?>"><?php esc_html_e('Linked In:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'linkedin' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'linkedin' )); ?>" value="<?php echo esc_html($instance['linkedin']); ?>" />
        </p>
        
        
        <!-- Rss -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'rss' )); ?>"><?php esc_html_e('Rss:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'rss' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'rss' )); ?>" value="<?php echo esc_html($instance['rss']); ?>" />
        </p>
                    
        
        <!-- pinterest -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'pinterest' )); ?>"><?php esc_html_e('Pinterest:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'pinterest' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'pinterest' )); ?>" value="<?php echo esc_html($instance['pinterest']); ?>" />
        </p>
               
        
        <!-- xing -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'xing' )); ?>"><?php esc_html_e('Xing:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'xing' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'xing' )); ?>" value="<?php echo esc_html($instance['xing']); ?>" />
        </p>
        
       
        <!-- dropbox -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'dropbox' )); ?>"><?php esc_html_e('Dropbox:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'dropbox' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'dropbox' )); ?>" value="<?php echo esc_html($instance['dropbox']); ?>" />
        </p>
        
        
        <!-- stumbleupon -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'stumbleupon' )); ?>"><?php esc_html_e('Stumbleupon:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'stumbleupon' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'stumbleupon' )); ?>" value="<?php echo esc_html($instance['stumbleupon']); ?>" />
        </p>
        
        
        <!-- delicious -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'delicious' )); ?>"><?php esc_html_e('Delicious:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'delicious' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'delicious' )); ?>" value="<?php echo esc_html($instance['delicious']); ?>" />
        </p>
        
        
        <!-- soundcloud -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'soundcloud' )); ?>"><?php esc_html_e('Soundcloud:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'soundcloud' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'soundcloud' )); ?>" value="<?php echo esc_html($instance['soundcloud']); ?>" />
        </p>
        
        
        <!-- spotify -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'spotify' )); ?>"><?php esc_html_e('Spotify:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'spotify' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'spotify' )); ?>" value="<?php echo esc_html($instance['spotify']); ?>" />
        </p>
        
        
        <!-- codepen -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'codepen' )); ?>"><?php esc_html_e('Codepen:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'codepen' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'codepen' )); ?>" value="<?php echo esc_html($instance['codepen']); ?>" />
        </p>
        
        
        <!-- github -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'github' )); ?>"><?php esc_html_e('Github:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'github' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'github' )); ?>" value="<?php echo esc_html($instance['github']); ?>" />
        </p>
        
        
        <!-- jsfiddle -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'jsfiddle' )); ?>"><?php esc_html_e('Jsfiddle:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'jsfiddle' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'jsfiddle' )); ?>" value="<?php echo esc_html($instance['jsfiddle']); ?>" />
        </p>
        
        
         <!-- lastfm -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'lastfm' )); ?>"><?php esc_html_e('Lastfm:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'lastfm' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'lastfm' )); ?>" value="<?php echo esc_html($instance['lastfm']); ?>" />
        </p>
        
        
         <!-- mixcloud -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'mixcloud' )); ?>"><?php esc_html_e('Mixcloud:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'mixcloud' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'mixcloud' )); ?>" value="<?php echo esc_html($instance['mixcloud']); ?>" />
        </p>
     
        
            
        <!-- tumblr -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'tumblr' )); ?>"><?php esc_html_e('Tumblr:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'tumblr' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'tumblr' )); ?>" value="<?php echo esc_html($instance['tumblr']); ?>" />
        </p>
        
         
        <!-- skype -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'skype' )); ?>"><?php esc_html_e('Skype:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'skype' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'skype' )); ?>" value="<?php echo esc_html($instance['skype']); ?>" />
        </p>
        
        
        <!-- vk -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'vk' )); ?>"><?php esc_html_e('Vk:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'vk' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'vk' )); ?>" value="<?php echo esc_html($instance['vk']); ?>" />
        </p>
        
        
        <!-- mail -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'mail' )); ?>"><?php esc_html_e('Email:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'mail' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'mail' )); ?>" value="<?php echo esc_html($instance['mail']); ?>" /><em>Add "mailto:" in front</em>
        </p>
        
        
        <!-- url -->
		<p>
		<label for="<?php echo esc_attr($this->get_field_id( 'url' )); ?>"><?php esc_html_e('Website:', 'dani') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'url' )); ?>" value="<?php echo esc_html($instance['url']); ?>" /><em>Add "http://" in front</em>
        </p>
                    		
		
	<?php
	}
}

?>