<?php

/*-----------------------------------------------------------------------------------
	
	Plugin Name: Dribbble Widget 
	Description: Display your Dribbbles   
	Version: 1.0  
	Author: SpabRice  
	Author URI: http://www.spab-rice.com  
	
-----------------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------------*/
/*	Register dribbble Widget & enqueu scripts
/*-----------------------------------------------------------------------------------*/

add_action( 'widgets_init', 'sr_dribbble_widget' );

function sr_dribbble_widget() {
	register_widget( 'sr_dribbble_widget' );
}




/*-----------------------------------------------------------------------------------*/
/*	Widget Class
/*-----------------------------------------------------------------------------------*/

class sr_dribbble_widget extends WP_Widget {

	/*  Widget setup  */
	
	function __construct() {
	
		// Widget settings
		$widget_ops = array( 'classname' => 'sr_dribbble_widget', 'description' => esc_html__('A simple Dribbble widget to show your Dribbble shots.', 'dani') );
		$control_ops = array( 'width' => 200, 'height' => 350, 'id_base', 'sr-dribbble-widget' );

		// Create widget
		parent::__construct( 'sr_dribbble_widget', esc_html__('SR - Dribbbles','dani'), $widget_ops, $control_ops );
	}
	


	/*  Display Widget */
	
	function widget( $args, $instance ) {
		extract( $args );

		// Get the inputs
		$sr_title = apply_filters('widget_title', $instance['title'] );
		$sr_dribbble_name = $instance['dribbblename'];
		$sr_dribbble_amount = $instance['dribbbleitems'];
		$sr_dribbble_token = $instance['dribbbletoken'];
		
		// Display the WidgetBefore settings
		echo $before_widget;
		
		
		// Display the title
		if ( $sr_title ) { echo $before_title . $sr_title . $after_title; }
			
			
		$id = rand(0,9999);
		/* Display Latest dribbble */
		?>
            <div class="dribbble-widget col-4" 
            	data-user="<?php echo esc_attr($sr_dribbble_name); ?>" 
                data-count="<?php echo esc_attr($sr_dribbble_amount); ?>" 
                data-accesstoken="<?php echo esc_attr($sr_dribbble_token); ?>"></div>
         <?php   
		
		
		// Display the WidgetAfter settings
		echo $after_widget;
		
		wp_register_script('jribbble', get_template_directory_uri() . '/files/js/jribbble.min.js', 'jquery', '2.0.4', true);
		wp_enqueue_script('jribbble');
		
	} // END function
	
	

	/* Update Widget */
	
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['dribbblename'] = strip_tags( $new_instance['dribbblename'] );
		$instance['dribbbleitems'] = strip_tags( $new_instance['dribbbleitems'] );
		$instance['dribbbletoken'] = strip_tags( $new_instance['dribbbletoken'] );

		return $instance;
	}
	
	/* Widget settings */
	
		 
	function form( $instance ) {

		// Set up default settings
		$defaults = array(
		'title' => 'My dribbble',
		'dribbblename' => 'spabrice',
		'dribbbleitems' => '8',
		'dribbbletoken' => ''
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); 
		
		?>

		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo  esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e('Title:', 'dani') ?></label>
			<input type="text" class="widefat" id="<?php echo  esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo  esc_attr($this->get_field_name( 'title' )); ?>" value="<?php echo esc_html($instance['title']); ?>" />
		</p>

		<!-- dribbble ID: Text Input -->
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'dribbblename' )); ?>"><?php esc_html_e('Dribbble Name', 'dani') ?></label>
			<input type="text" class="widefat" id="<?php echo  esc_attr($this->get_field_id( 'dribbblename' )); ?>" name="<?php echo  esc_attr($this->get_field_name( 'dribbblename' )); ?>" value="<?php echo esc_html($instance['dribbblename']); ?>" />
		</p>
        
        <!-- dribbble Items: Text Input -->
		<p>
			<label for="<?php echo  esc_attr($this->get_field_id( 'dribbbleitems' )); ?>"><?php esc_html_e('Dribbble Items', 'dani') ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'dribbbleitems' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'dribbbleitems' )); ?>" value="<?php echo esc_html($instance['dribbbleitems']); ?>" />
            <small><?php esc_html_e('Choose a number of items', 'dani'); ?></small>
		</p>
        
        <!-- dribbble Token: Text Input -->
		<p>
			<label for="<?php echo  esc_attr($this->get_field_id( 'dribbbletoken' )); ?>"><?php esc_html_e('Client Access Token', 'dani') ?></label>
			<input type="text" class="widefat" id="<?php echo  esc_attr($this->get_field_id( 'dribbbletoken' )); ?>" name="<?php echo  esc_attr($this->get_field_name( 'dribbbletoken' )); ?>" value="<?php echo esc_html($instance['dribbbletoken']); ?>" />
            <small><?php esc_html_e('Enter your Access Token', 'dani'); ?></small>
		</p>
			
		
		
	<?php
	}
}

?>