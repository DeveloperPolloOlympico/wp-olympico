*** DANI Core (custom post types, page builder,widgets,shortcodes) ***


August 20 2015 - Version 1.1
	
	* First Release

