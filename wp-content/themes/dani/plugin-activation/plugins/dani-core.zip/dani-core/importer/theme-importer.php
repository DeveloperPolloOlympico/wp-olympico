<?php 

/*-----------------------------------------------------------------------------------

	Extended  WP Importer by SpabRice for custom navigations fields

-----------------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------------*/
/*	Import Function
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'dani_theme_importoptions' ) ) {
	function dani_theme_importoptions($file,$xml=null) {
		
		
		
		// ---------------------------------
		// Content Import
		// ---------------------------------

		// Include Custom Importer Class 
		require_once( plugin_dir_path( __FILE__ ) . "/wp-importer/wordpress-importer.php");
		
		// Import file
		$newimport = new SR_CUSTOM_WP_Import();
		$data = sanitize_file_name($file);
		$content_file = plugin_dir_path( __FILE__ ) . '/datas/'.$data.'.xml';
		if ( file_exists( $content_file ) ) {
			$newimport->fetch_attachments = true; ob_start();
			$newimport->import($content_file); ob_end_clean();				
		} else {
			wp_redirect( admin_url( 'themes.php?page=option-panel.php&import=false' ) );
		}
		
		
				
		
		// ---------------------------------
		// Update Menu Location
		// ---------------------------------
		$nav_location = get_theme_mod( 'nav_menu_locations' ); 
		$menus = wp_get_nav_menus(); 
		
		// Assign Main Menu to location
		if( is_array($menus) ) {
			foreach($menus as $menu) { 
				if( $menu->name == 'Main Menu' ) { $nav_location['primary-menu'] = $menu->term_id; }
			}
		}
		set_theme_mod( 'nav_menu_locations', $nav_location );
		
		
		
		// ---------------------------------
		// Update Reading Settings
		// ---------------------------------
		$homePage = get_page_by_title( 'Home' );
		$blogPage = get_page_by_title( 'Blog' );
		if( isset($homePage->ID) || isset($blogPage->ID) ) {
			update_option('show_on_front', 'page');
			if( isset($homePage->ID) ) {	update_option('page_on_front',  $homePage->ID); }
			if( isset($blogPage->ID) ) {	update_option('page_for_posts', $blogPage->ID);  }
		}
		
		
		
		// ---------------------------------
		// Update Theme Options
		// ---------------------------------
		$option_file = plugin_dir_path( __FILE__ ) . '/datas/'.$xml.'.txt';
		$options_content = file_get_contents( $option_file );
		$options = explode("|:|", $options_content);
		
		foreach ($options as $o) {
			$split_o = explode(";:;", $o);
			$name_o = $split_o[0];
			$val_o = $split_o[1];
			if ($val_o && $val_o !== '') { 
				$val = str_replace('dani_SITE_URL',home_url(),$val_o);
				update_option( $name_o, $val ); }
		}
		update_option( '_sr_optiontree', $options_content );
		
		
		// Add option that the import has been done
		update_option( '_sr_import_state', 'true' );
		
		
	}
}




/*-----------------------------------------------------------------------------------*/
/*	Replace pagebuilder "|;|" by "\"
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'dani_theme_import_updatepagebuilder' ) ) {
	function dani_theme_import_updatepagebuilder() {
		/*	
		# Pages
		$pages = get_pages(); 
		foreach ( $pages as $page ) {
			$oldVal = get_post_meta($page->ID, '_sr_pagebuilder_json', true);
			if (strpos($oldVal,'|;|') !== false) {
				$newVal = str_replace("|;|",'\\\\',$oldVal);
				update_post_meta($page->ID, '_sr_pagebuilder_json', $newVal);
			}
		}
		
		# Posts
		$posts = get_posts( array('post_type' => 'post', 'posts_per_page' => -1) );
		foreach ( $posts as $post ) {
			$oldVal = get_post_meta($post->ID, '_sr_pagebuilder_json', true);
			if (strpos($oldVal,'|;|') !== false) {
				$newVal = str_replace("|;|",'\\\\',$oldVal);
				update_post_meta($post->ID, '_sr_pagebuilder_json', $newVal);
			}
		}
		
		# Portfolios
		$portfolios = get_posts( array('post_type' => 'portfolio', 'posts_per_page' => -1) );
		foreach ( $portfolios as $portfolio ) {
			$oldVal = get_post_meta($portfolio->ID, '_sr_pagebuilder_json', true);
			if (strpos($oldVal,'|;|') !== false) {
				$newVal = str_replace("|;|",'\\\\',$oldVal);
				update_post_meta($portfolio->ID, '_sr_pagebuilder_json', $newVal);
			}
		}
		*/
	}
}

?>